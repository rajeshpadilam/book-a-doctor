import { FiTarget, FiUsers, FiShield } from "react-icons/fi";

const About = () => {
  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      <h1 className="text-3xl font-bold text-center mb-4">About BookADoctor</h1>
      <p className="text-center text-gray-500 dark:text-gray-400 max-w-2xl mx-auto mb-12">
        BookADoctor connects patients with verified, experienced doctors across specializations,
        making healthcare booking simple, transparent, and fast.
      </p>

      <div className="grid sm:grid-cols-3 gap-8">
        <div className="card p-6 text-center">
          <FiTarget className="text-3xl text-primary-600 mx-auto mb-3" />
          <h3 className="font-semibold mb-1">Our Mission</h3>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Make quality healthcare accessible to everyone with just a few clicks.
          </p>
        </div>
        <div className="card p-6 text-center">
          <FiUsers className="text-3xl text-primary-600 mx-auto mb-3" />
          <h3 className="font-semibold mb-1">Our Doctors</h3>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Verified specialists across 10+ fields, from general physicians to psychiatrists.
          </p>
        </div>
        <div className="card p-6 text-center">
          <FiShield className="text-3xl text-primary-600 mx-auto mb-3" />
          <h3 className="font-semibold mb-1">Trust & Privacy</h3>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Your data and appointments are secured with industry-standard practices.
          </p>
        </div>
      </div>
    </div>
  );
};

export default About;
