import { useState, useRef } from "react";
import toast from "react-hot-toast";
import { FiCamera } from "react-icons/fi";
import api from "../../api/axios";
import { useAuth } from "../../context/AuthContext";

const PatientProfile = () => {
  const { user, updateUserInStorage } = useAuth();
  const fileRef = useRef();

  const [form, setForm] = useState({
    name: user?.name || "",
    phone: user?.phone || "",
    gender: user?.gender || "male",
    dateOfBirth: user?.dateOfBirth ? user.dateOfBirth.split("T")[0] : "",
    address: user?.address || "",
  });
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const { data } = await api.put("/patients/profile", form);
      updateUserInStorage({ name: data.user.name });
      toast.success("Profile updated successfully");
    } catch (err) {
      toast.error(err.response?.data?.message || "Update failed");
    } finally {
      setSaving(false);
    }
  };

  const handleImageUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const formData = new FormData();
    formData.append("image", file);

    setUploading(true);
    try {
      const { data } = await api.put("/patients/profile/image", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      updateUserInStorage({ profileImage: data.profileImage });
      toast.success("Profile picture updated");
    } catch (err) {
      toast.error(err.response?.data?.message || "Upload failed");
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="max-w-2xl">
      <h1 className="text-2xl font-bold mb-6">My Profile</h1>

      <div className="flex items-center gap-4 mb-8">
        <div className="relative">
          <img
            src={user?.profileImage?.url || "https://placehold.co/100?text=User"}
            alt="Profile"
            className="w-20 h-20 rounded-full object-cover border-2 border-primary-200"
          />
          <button
            onClick={() => fileRef.current.click()}
            className="absolute bottom-0 right-0 bg-primary-600 text-white p-1.5 rounded-full"
          >
            <FiCamera size={12} />
          </button>
          <input ref={fileRef} type="file" accept="image/*" hidden onChange={handleImageUpload} />
        </div>
        <div>
          <p className="font-medium">{user?.name}</p>
          <p className="text-sm text-gray-500">{user?.email}</p>
          {uploading && <p className="text-xs text-primary-600 mt-1">Uploading...</p>}
        </div>
      </div>

      <form onSubmit={handleSave} className="card p-6 space-y-4">
        <div>
          <label className="text-sm font-medium">Full Name</label>
          <input name="name" value={form.name} onChange={handleChange} className="input-field mt-1" />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-sm font-medium">Phone</label>
            <input name="phone" value={form.phone} onChange={handleChange} className="input-field mt-1" />
          </div>
          <div>
            <label className="text-sm font-medium">Gender</label>
            <select name="gender" value={form.gender} onChange={handleChange} className="input-field mt-1">
              <option value="male">Male</option>
              <option value="female">Female</option>
              <option value="other">Other</option>
            </select>
          </div>
        </div>
        <div>
          <label className="text-sm font-medium">Date of Birth</label>
          <input type="date" name="dateOfBirth" value={form.dateOfBirth} onChange={handleChange} className="input-field mt-1" />
        </div>
        <div>
          <label className="text-sm font-medium">Address</label>
          <textarea name="address" value={form.address} onChange={handleChange} rows={2} className="input-field mt-1" />
        </div>
        <button disabled={saving} className="btn-primary">
          {saving ? "Saving..." : "Save Changes"}
        </button>
      </form>
    </div>
  );
};

export default PatientProfile;
