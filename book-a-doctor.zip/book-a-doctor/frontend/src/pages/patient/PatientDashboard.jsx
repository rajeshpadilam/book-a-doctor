import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { FiCalendar, FiClock, FiCheckCircle } from "react-icons/fi";
import api from "../../api/axios";
import { useAuth } from "../../context/AuthContext";
import Spinner from "../../components/common/Spinner";

const statusColors = {
  pending: "bg-yellow-100 text-yellow-700",
  accepted: "bg-blue-100 text-blue-700",
  completed: "bg-green-100 text-green-700",
  rejected: "bg-red-100 text-red-700",
  cancelled: "bg-gray-100 text-gray-700",
};

const PatientDashboard = () => {
  const { user } = useAuth();
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api
      .get("/patients/appointments")
      .then((res) => setAppointments(res.data.appointments))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <Spinner fullScreen />;

  const upcoming = appointments.filter((a) => ["pending", "accepted"].includes(a.status));
  const completed = appointments.filter((a) => a.status === "completed");

  return (
    <div>
      <h1 className="text-2xl font-bold mb-1">Welcome, {user?.name?.split(" ")[0]} 👋</h1>
      <p className="text-gray-500 dark:text-gray-400 mb-8">Here's an overview of your appointments.</p>

      <div className="grid sm:grid-cols-3 gap-4 mb-10">
        <div className="card p-5 flex items-center gap-4">
          <div className="p-3 bg-primary-100 dark:bg-primary-900 rounded-lg text-primary-600"><FiCalendar /></div>
          <div>
            <p className="text-xl font-bold">{appointments.length}</p>
            <p className="text-xs text-gray-500">Total Appointments</p>
          </div>
        </div>
        <div className="card p-5 flex items-center gap-4">
          <div className="p-3 bg-yellow-100 dark:bg-yellow-900 rounded-lg text-yellow-600"><FiClock /></div>
          <div>
            <p className="text-xl font-bold">{upcoming.length}</p>
            <p className="text-xs text-gray-500">Upcoming</p>
          </div>
        </div>
        <div className="card p-5 flex items-center gap-4">
          <div className="p-3 bg-green-100 dark:bg-green-900 rounded-lg text-green-600"><FiCheckCircle /></div>
          <div>
            <p className="text-xl font-bold">{completed.length}</p>
            <p className="text-xs text-gray-500">Completed</p>
          </div>
        </div>
      </div>

      <div className="flex items-center justify-between mb-4">
        <h2 className="font-semibold">Upcoming Appointments</h2>
        <Link to="/patient/appointments" className="text-sm text-primary-600">View all →</Link>
      </div>

      {upcoming.length === 0 ? (
        <p className="text-sm text-gray-500">No upcoming appointments. <Link to="/doctors" className="text-primary-600">Book one now</Link>.</p>
      ) : (
        <div className="space-y-3">
          {upcoming.slice(0, 5).map((a) => (
            <div key={a._id} className="card p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <img src={a.doctor?.photo?.url || "https://placehold.co/50"} alt="" className="w-10 h-10 rounded-full object-cover" />
                <div>
                  <p className="font-medium text-sm">Dr. {a.doctor?.name}</p>
                  <p className="text-xs text-gray-500">{a.doctor?.specialization} · {new Date(a.date).toLocaleDateString()} at {a.timeSlot}</p>
                </div>
              </div>
              <span className={`text-xs px-2 py-1 rounded-full capitalize ${statusColors[a.status]}`}>{a.status}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default PatientDashboard;
