import { useEffect, useState } from "react";
import toast from "react-hot-toast";
import api from "../../api/axios";
import Spinner from "../../components/common/Spinner";

const statusColors = {
  pending: "bg-yellow-100 text-yellow-700",
  accepted: "bg-blue-100 text-blue-700",
  completed: "bg-green-100 text-green-700",
  rejected: "bg-red-100 text-red-700",
  cancelled: "bg-gray-100 text-gray-700",
};

const filters = ["all", "pending", "accepted", "completed", "cancelled", "rejected"];

const MyAppointments = () => {
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("all");
  const [reviewFor, setReviewFor] = useState(null);
  const [reviewData, setReviewData] = useState({ rating: 5, comment: "" });

  const fetchAppointments = async () => {
    setLoading(true);
    try {
      const query = filter !== "all" ? `?status=${filter}` : "";
      const { data } = await api.get(`/patients/appointments${query}`);
      setAppointments(data.appointments);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAppointments();
  }, [filter]);

  const handleCancel = async (id) => {
    if (!window.confirm("Cancel this appointment?")) return;
    try {
      await api.put(`/patients/appointments/${id}/cancel`);
      toast.success("Appointment cancelled");
      fetchAppointments();
    } catch (err) {
      toast.error(err.response?.data?.message || "Failed to cancel");
    }
  };

  const submitReview = async (appointmentId) => {
    try {
      await api.post("/patients/reviews", { appointmentId, ...reviewData });
      toast.success("Review submitted!");
      setReviewFor(null);
      setReviewData({ rating: 5, comment: "" });
    } catch (err) {
      toast.error(err.response?.data?.message || "Failed to submit review");
    }
  };

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">My Appointments</h1>

      <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
        {filters.map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`text-xs px-3 py-1.5 rounded-full capitalize whitespace-nowrap border ${
              filter === f ? "bg-primary-600 text-white border-primary-600" : "border-gray-200 dark:border-gray-700"
            }`}
          >
            {f}
          </button>
        ))}
      </div>

      {loading ? (
        <Spinner fullScreen />
      ) : appointments.length === 0 ? (
        <p className="text-sm text-gray-500">No appointments found.</p>
      ) : (
        <div className="space-y-4">
          {appointments.map((a) => (
            <div key={a._id} className="card p-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <img src={a.doctor?.photo?.url || "https://placehold.co/50"} alt="" className="w-12 h-12 rounded-full object-cover" />
                  <div>
                    <p className="font-medium text-sm">Dr. {a.doctor?.name}</p>
                    <p className="text-xs text-gray-500">{a.doctor?.specialization} · {a.doctor?.hospital}</p>
                    <p className="text-xs text-gray-500 mt-1">{new Date(a.date).toLocaleDateString()} at {a.timeSlot} · ₹{a.consultationFee}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className={`text-xs px-2 py-1 rounded-full capitalize ${statusColors[a.status]}`}>{a.status}</span>
                  {["pending", "accepted"].includes(a.status) && (
                    <button onClick={() => handleCancel(a._id)} className="text-xs text-red-600 border border-red-200 px-3 py-1.5 rounded-lg hover:bg-red-50">
                      Cancel
                    </button>
                  )}
                  {a.status === "completed" && (
                    <button onClick={() => setReviewFor(reviewFor === a._id ? null : a._id)} className="text-xs btn-outline py-1.5">
                      Leave Review
                    </button>
                  )}
                </div>
              </div>

              {reviewFor === a._id && (
                <div className="mt-4 pt-4 border-t border-gray-100 dark:border-gray-800">
                  <label className="text-sm font-medium">Rating</label>
                  <select
                    value={reviewData.rating}
                    onChange={(e) => setReviewData({ ...reviewData, rating: Number(e.target.value) })}
                    className="input-field mt-1 mb-3 w-32"
                  >
                    {[5, 4, 3, 2, 1].map((r) => <option key={r} value={r}>{r} Stars</option>)}
                  </select>
                  <textarea
                    value={reviewData.comment}
                    onChange={(e) => setReviewData({ ...reviewData, comment: e.target.value })}
                    placeholder="Share your experience..."
                    rows={2}
                    className="input-field mb-3"
                  />
                  <button onClick={() => submitReview(a._id)} className="btn-primary text-sm py-1.5">Submit Review</button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default MyAppointments;
