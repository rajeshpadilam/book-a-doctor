import { Outlet } from "react-router-dom";
import { FiGrid, FiCalendar, FiUser } from "react-icons/fi";
import DashboardSidebar from "../../components/common/DashboardSidebar";

const links = [
  { name: "Overview", path: "/patient/dashboard", icon: <FiGrid /> },
  { name: "Appointments", path: "/patient/appointments", icon: <FiCalendar /> },
  { name: "Profile", path: "/patient/profile", icon: <FiUser /> },
];

const PatientLayout = () => {
  return (
    <div className="flex flex-col md:flex-row">
      <DashboardSidebar links={links} title="Patient Panel" />
      <main className="flex-1 p-4 sm:p-6 lg:p-8">
        <Outlet />
      </main>
    </div>
  );
};

export default PatientLayout;
