import { useEffect, useState, useRef } from "react";
import toast from "react-hot-toast";
import { FiCamera } from "react-icons/fi";
import api from "../../api/axios";
import { useAuth } from "../../context/AuthContext";
import Spinner from "../../components/common/Spinner";

const SPECIALIZATIONS = [
  "General Physician", "Cardiologist", "Dermatologist", "Neurologist", "Orthopedic",
  "Pediatrician", "Dentist", "ENT", "Gynecologist", "Psychiatrist",
];

const DoctorProfile = () => {
  const { updateUserInStorage } = useAuth();
  const fileRef = useRef();
  const [form, setForm] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [photo, setPhoto] = useState(null);

  useEffect(() => {
    api.get("/auth/me").then((res) => {
      const d = res.data.user;
      setForm({
        name: d.name || "",
        phone: d.phone || "",
        qualification: d.qualification || "",
        experience: d.experience || 0,
        specialization: d.specialization || SPECIALIZATIONS[0],
        hospital: d.hospital || "",
        consultationFee: d.consultationFee || 0,
        languages: (d.languages || []).join(", "),
        about: d.about || "",
      });
      setPhoto(d.photo);
      setLoading(false);
    });
  }, []);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const payload = { ...form, languages: form.languages.split(",").map((l) => l.trim()).filter(Boolean) };
      const { data } = await api.put("/doctor/profile", payload);
      updateUserInStorage({ name: data.doctor.name });
      toast.success("Profile updated successfully");
    } catch (err) {
      toast.error(err.response?.data?.message || "Update failed");
    } finally {
      setSaving(false);
    }
  };

  const handleImageUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const formData = new FormData();
    formData.append("image", file);
    setUploading(true);
    try {
      const { data } = await api.put("/doctor/profile/image", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      setPhoto(data.photo);
      updateUserInStorage({ profileImage: data.photo });
      toast.success("Photo updated");
    } catch (err) {
      toast.error(err.response?.data?.message || "Upload failed");
    } finally {
      setUploading(false);
    }
  };

  if (loading || !form) return <Spinner fullScreen />;

  return (
    <div className="max-w-2xl">
      <h1 className="text-2xl font-bold mb-6">Doctor Profile</h1>

      <div className="flex items-center gap-4 mb-8">
        <div className="relative">
          <img src={photo?.url || "https://placehold.co/100?text=Dr"} alt="" className="w-20 h-20 rounded-full object-cover border-2 border-primary-200" />
          <button onClick={() => fileRef.current.click()} className="absolute bottom-0 right-0 bg-primary-600 text-white p-1.5 rounded-full">
            <FiCamera size={12} />
          </button>
          <input ref={fileRef} type="file" accept="image/*" hidden onChange={handleImageUpload} />
        </div>
        {uploading && <p className="text-xs text-primary-600">Uploading...</p>}
      </div>

      <form onSubmit={handleSave} className="card p-6 space-y-4">
        <div>
          <label className="text-sm font-medium">Full Name</label>
          <input name="name" value={form.name} onChange={handleChange} className="input-field mt-1" />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-sm font-medium">Phone</label>
            <input name="phone" value={form.phone} onChange={handleChange} className="input-field mt-1" />
          </div>
          <div>
            <label className="text-sm font-medium">Experience (years)</label>
            <input type="number" name="experience" value={form.experience} onChange={handleChange} className="input-field mt-1" />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-sm font-medium">Qualification</label>
            <input name="qualification" value={form.qualification} onChange={handleChange} className="input-field mt-1" />
          </div>
          <div>
            <label className="text-sm font-medium">Specialization</label>
            <select name="specialization" value={form.specialization} onChange={handleChange} className="input-field mt-1">
              {SPECIALIZATIONS.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-sm font-medium">Hospital</label>
            <input name="hospital" value={form.hospital} onChange={handleChange} className="input-field mt-1" />
          </div>
          <div>
            <label className="text-sm font-medium">Consultation Fee (₹)</label>
            <input type="number" name="consultationFee" value={form.consultationFee} onChange={handleChange} className="input-field mt-1" />
          </div>
        </div>
        <div>
          <label className="text-sm font-medium">Languages (comma separated)</label>
          <input name="languages" value={form.languages} onChange={handleChange} className="input-field mt-1" placeholder="English, Hindi" />
        </div>
        <div>
          <label className="text-sm font-medium">About</label>
          <textarea name="about" value={form.about} onChange={handleChange} rows={4} className="input-field mt-1" />
        </div>
        <button disabled={saving} className="btn-primary">{saving ? "Saving..." : "Save Changes"}</button>
      </form>
    </div>
  );
};

export default DoctorProfile;
