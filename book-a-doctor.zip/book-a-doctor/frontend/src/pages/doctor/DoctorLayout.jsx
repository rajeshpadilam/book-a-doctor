import { Outlet } from "react-router-dom";
import { FiGrid, FiCalendar, FiClock, FiUser, FiDollarSign } from "react-icons/fi";
import DashboardSidebar from "../../components/common/DashboardSidebar";

const links = [
  { name: "Dashboard", path: "/doctor/dashboard", icon: <FiGrid /> },
  { name: "Appointments", path: "/doctor/appointments", icon: <FiCalendar /> },
  { name: "Availability", path: "/doctor/availability", icon: <FiClock /> },
  { name: "Earnings", path: "/doctor/earnings", icon: <FiDollarSign /> },
  { name: "Profile", path: "/doctor/profile", icon: <FiUser /> },
];

const DoctorLayout = () => {
  return (
    <div className="flex flex-col md:flex-row">
      <DashboardSidebar links={links} title="Doctor Panel" />
      <main className="flex-1 p-4 sm:p-6 lg:p-8">
        <Outlet />
      </main>
    </div>
  );
};

export default DoctorLayout;
