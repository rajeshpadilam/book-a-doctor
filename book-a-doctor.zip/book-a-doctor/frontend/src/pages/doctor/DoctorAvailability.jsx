import { useEffect, useState } from "react";
import toast from "react-hot-toast";
import { FiPlus, FiTrash2 } from "react-icons/fi";
import api from "../../api/axios";
import { useAuth } from "../../context/AuthContext";
import Spinner from "../../components/common/Spinner";

const WEEKDAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];

const DoctorAvailability = () => {
  const [availability, setAvailability] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [newSlot, setNewSlot] = useState({});

  useEffect(() => {
    // /auth/me returns the full doctor document (including availability) for the logged-in doctor
    api.get("/auth/me").then((res) => {
      setAvailability(res.data.user.availability || []);
      setLoading(false);
    });
  }, []);

  const addDay = (day) => {
    if (availability.find((a) => a.day === day)) return;
    setAvailability([...availability, { day, slots: [] }]);
  };

  const removeDay = (day) => {
    setAvailability(availability.filter((a) => a.day !== day));
  };

  const addSlot = (day) => {
    const slot = newSlot[day];
    if (!slot) return;
    setAvailability(
      availability.map((a) => (a.day === day ? { ...a, slots: [...a.slots, slot] } : a))
    );
    setNewSlot({ ...newSlot, [day]: "" });
  };

  const removeSlot = (day, slot) => {
    setAvailability(
      availability.map((a) => (a.day === day ? { ...a, slots: a.slots.filter((s) => s !== slot) } : a))
    );
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await api.put("/doctor/availability", { availability });
      toast.success("Availability updated successfully");
    } catch (err) {
      toast.error(err.response?.data?.message || "Update failed");
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <Spinner fullScreen />;

  const unusedDays = WEEKDAYS.filter((d) => !availability.find((a) => a.day === d));

  return (
    <div className="max-w-3xl">
      <h1 className="text-2xl font-bold mb-2">Manage Availability</h1>
      <p className="text-gray-500 dark:text-gray-400 mb-6 text-sm">
        Add the days you're available and the time slots patients can book.
      </p>

      {unusedDays.length > 0 && (
        <div className="mb-6">
          <label className="text-sm font-medium">Add a day</label>
          <div className="flex flex-wrap gap-2 mt-2">
            {unusedDays.map((day) => (
              <button key={day} onClick={() => addDay(day)} className="text-xs btn-outline py-1.5 flex items-center gap-1">
                <FiPlus /> {day}
              </button>
            ))}
          </div>
        </div>
      )}

      <div className="space-y-4">
        {availability.map((a) => (
          <div key={a.day} className="card p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-semibold">{a.day}</h3>
              <button onClick={() => removeDay(a.day)} className="text-red-500 hover:text-red-700">
                <FiTrash2 />
              </button>
            </div>

            <div className="flex flex-wrap gap-2 mb-3">
              {a.slots.map((slot) => (
                <span key={slot} className="flex items-center gap-1 text-xs bg-primary-50 dark:bg-gray-700 text-primary-700 dark:text-primary-300 px-2 py-1 rounded-full">
                  {slot}
                  <button onClick={() => removeSlot(a.day, slot)}><FiTrash2 size={10} /></button>
                </span>
              ))}
              {a.slots.length === 0 && <p className="text-xs text-gray-400">No slots added yet.</p>}
            </div>

            <div className="flex gap-2">
              <input
                type="text"
                placeholder="e.g. 10:00 AM"
                value={newSlot[a.day] || ""}
                onChange={(e) => setNewSlot({ ...newSlot, [a.day]: e.target.value })}
                className="input-field text-sm flex-1"
              />
              <button onClick={() => addSlot(a.day)} className="btn-outline text-sm px-3">Add</button>
            </div>
          </div>
        ))}
      </div>

      {availability.length > 0 && (
        <button onClick={handleSave} disabled={saving} className="btn-primary mt-6">
          {saving ? "Saving..." : "Save Availability"}
        </button>
      )}
    </div>
  );
};

export default DoctorAvailability;
