import { useEffect, useState } from "react";
import { FiCalendar, FiCheckCircle, FiClock, FiDollarSign, FiStar } from "react-icons/fi";
import toast from "react-hot-toast";
import api from "../../api/axios";
import Spinner from "../../components/common/Spinner";

const DoctorDashboard = () => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    setLoading(true);
    try {
      const { data } = await api.get("/doctor/dashboard");
      setData(data);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleAction = async (id, action) => {
    try {
      await api.put(`/doctor/appointments/${id}/${action}`);
      toast.success(`Appointment ${action}ed`);
      fetchData();
    } catch (err) {
      toast.error(err.response?.data?.message || "Action failed");
    }
  };

  if (loading || !data) return <Spinner fullScreen />;

  const { stats, todayAppointments } = data;

  const cards = [
    { label: "Total Appointments", value: stats.totalAppointments, icon: <FiCalendar />, className: "bg-primary-100 text-primary-600 dark:bg-primary-900" },
    { label: "Pending", value: stats.pending, icon: <FiClock />, className: "bg-yellow-100 text-yellow-600 dark:bg-yellow-900" },
    { label: "Completed", value: stats.completed, icon: <FiCheckCircle />, className: "bg-green-100 text-green-600 dark:bg-green-900" },
    { label: "Earnings", value: `₹${stats.earnings}`, icon: <FiDollarSign />, className: "bg-purple-100 text-purple-600 dark:bg-purple-900" },
  ];

  return (
    <div>
      <h1 className="text-2xl font-bold mb-1">Doctor Dashboard</h1>
      <p className="text-gray-500 dark:text-gray-400 mb-8 flex items-center gap-1">
        <FiStar className="text-yellow-500" /> {stats.rating || "No"} rating ({stats.numReviews} reviews)
      </p>

      <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-4 mb-10">
        {cards.map((c) => (
          <div key={c.label} className="card p-5 flex items-center gap-4">
            <div className={`p-3 rounded-lg ${c.className}`}>{c.icon}</div>
            <div>
              <p className="text-xl font-bold">{c.value}</p>
              <p className="text-xs text-gray-500">{c.label}</p>
            </div>
          </div>
        ))}
      </div>

      <h2 className="font-semibold mb-4">Today's Appointments</h2>
      {todayAppointments.length === 0 ? (
        <p className="text-sm text-gray-500">No appointments scheduled for today.</p>
      ) : (
        <div className="space-y-3">
          {todayAppointments.map((a) => (
            <div key={a._id} className="card p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <img src={a.patient?.profileImage?.url || "https://placehold.co/50"} alt="" className="w-10 h-10 rounded-full object-cover" />
                <div>
                  <p className="font-medium text-sm">{a.patient?.name}</p>
                  <p className="text-xs text-gray-500">{a.timeSlot} · {a.patient?.phone}</p>
                </div>
              </div>
              <div className="flex gap-2">
                {a.status === "pending" && (
                  <>
                    <button onClick={() => handleAction(a._id, "accept")} className="text-xs btn-primary py-1.5">Accept</button>
                    <button onClick={() => handleAction(a._id, "reject")} className="text-xs border border-red-200 text-red-600 px-3 py-1.5 rounded-lg">Reject</button>
                  </>
                )}
                {a.status === "accepted" && (
                  <button onClick={() => handleAction(a._id, "complete")} className="text-xs btn-primary py-1.5">Mark Complete</button>
                )}
                {["completed", "rejected", "cancelled"].includes(a.status) && (
                  <span className="text-xs capitalize text-gray-500">{a.status}</span>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default DoctorDashboard;
