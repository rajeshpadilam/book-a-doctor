import { useEffect, useState } from "react";
import toast from "react-hot-toast";
import api from "../../api/axios";
import Spinner from "../../components/common/Spinner";

const statusColors = {
  pending: "bg-yellow-100 text-yellow-700",
  accepted: "bg-blue-100 text-blue-700",
  completed: "bg-green-100 text-green-700",
  rejected: "bg-red-100 text-red-700",
  cancelled: "bg-gray-100 text-gray-700",
};

const filters = ["all", "pending", "accepted", "completed", "cancelled", "rejected"];

const DoctorAppointments = () => {
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("all");
  const [expanded, setExpanded] = useState(null);
  const [notes, setNotes] = useState("");

  const fetchAppointments = async () => {
    setLoading(true);
    try {
      const query = filter !== "all" ? `?status=${filter}` : "";
      const { data } = await api.get(`/doctor/appointments${query}`);
      setAppointments(data.appointments);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAppointments();
  }, [filter]);

  const handleAction = async (id, action, extra = {}) => {
    try {
      await api.put(`/doctor/appointments/${id}/${action}`, extra);
      toast.success(`Appointment ${action}ed`);
      setExpanded(null);
      setNotes("");
      fetchAppointments();
    } catch (err) {
      toast.error(err.response?.data?.message || "Action failed");
    }
  };

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Appointments</h1>

      <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
        {filters.map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`text-xs px-3 py-1.5 rounded-full capitalize whitespace-nowrap border ${
              filter === f ? "bg-primary-600 text-white border-primary-600" : "border-gray-200 dark:border-gray-700"
            }`}
          >
            {f}
          </button>
        ))}
      </div>

      {loading ? (
        <Spinner fullScreen />
      ) : appointments.length === 0 ? (
        <p className="text-sm text-gray-500">No appointments found.</p>
      ) : (
        <div className="space-y-4">
          {appointments.map((a) => (
            <div key={a._id} className="card p-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <img src={a.patient?.profileImage?.url || "https://placehold.co/50"} alt="" className="w-12 h-12 rounded-full object-cover" />
                  <div>
                    <p className="font-medium text-sm">{a.patient?.name}</p>
                    <p className="text-xs text-gray-500">{a.patient?.phone} · {a.patient?.email}</p>
                    <p className="text-xs text-gray-500 mt-1">{new Date(a.date).toLocaleDateString()} at {a.timeSlot}</p>
                    {a.reason && <p className="text-xs text-gray-500 italic mt-1">Reason: {a.reason}</p>}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className={`text-xs px-2 py-1 rounded-full capitalize ${statusColors[a.status]}`}>{a.status}</span>
                  {a.status === "pending" && (
                    <>
                      <button onClick={() => handleAction(a._id, "accept")} className="text-xs btn-primary py-1.5">Accept</button>
                      <button onClick={() => handleAction(a._id, "reject")} className="text-xs border border-red-200 text-red-600 px-3 py-1.5 rounded-lg">Reject</button>
                    </>
                  )}
                  {a.status === "accepted" && (
                    <button onClick={() => setExpanded(expanded === a._id ? null : a._id)} className="text-xs btn-primary py-1.5">
                      Complete
                    </button>
                  )}
                </div>
              </div>

              {expanded === a._id && (
                <div className="mt-4 pt-4 border-t border-gray-100 dark:border-gray-800">
                  <label className="text-sm font-medium">Consultation Notes (optional)</label>
                  <textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={2} className="input-field mt-1 mb-3" />
                  <button onClick={() => handleAction(a._id, "complete", { notes })} className="btn-primary text-sm py-1.5">
                    Confirm Completion
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default DoctorAppointments;
