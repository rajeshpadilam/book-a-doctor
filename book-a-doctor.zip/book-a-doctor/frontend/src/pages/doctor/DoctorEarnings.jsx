import { useEffect, useState } from "react";
import { FiDollarSign } from "react-icons/fi";
import api from "../../api/axios";
import Spinner from "../../components/common/Spinner";

const DoctorEarnings = () => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get("/doctor/earnings").then((res) => setData(res.data)).finally(() => setLoading(false));
  }, []);

  if (loading || !data) return <Spinner fullScreen />;

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Earnings</h1>

      <div className="card p-6 flex items-center gap-4 mb-8 max-w-sm">
        <div className="p-4 bg-primary-100 dark:bg-primary-900 text-primary-600 rounded-xl text-2xl">
          <FiDollarSign />
        </div>
        <div>
          <p className="text-2xl font-bold">₹{data.totalEarnings}</p>
          <p className="text-sm text-gray-500">from {data.completedCount} completed consultations</p>
        </div>
      </div>

      <h2 className="font-semibold mb-4">Transaction History</h2>
      {data.transactions.length === 0 ? (
        <p className="text-sm text-gray-500">No completed consultations yet.</p>
      ) : (
        <div className="card overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 dark:bg-gray-800 text-left">
              <tr>
                <th className="p-3">Patient</th>
                <th className="p-3">Date</th>
                <th className="p-3">Amount</th>
              </tr>
            </thead>
            <tbody>
              {data.transactions.map((t) => (
                <tr key={t._id} className="border-t border-gray-100 dark:border-gray-800">
                  <td className="p-3">{t.patient?.name}</td>
                  <td className="p-3">{new Date(t.date).toLocaleDateString()}</td>
                  <td className="p-3 font-medium">₹{t.consultationFee}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default DoctorEarnings;
