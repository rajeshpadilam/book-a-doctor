import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { FiStar, FiMapPin, FiClock, FiGlobe, FiCalendar } from "react-icons/fi";
import toast from "react-hot-toast";
import api from "../api/axios";
import Spinner from "../components/common/Spinner";
import { useAuth } from "../context/AuthContext";

const DoctorDetails = () => {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();

  const [doctor, setDoctor] = useState(null);
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);

  const [selectedDay, setSelectedDay] = useState("");
  const [selectedSlot, setSelectedSlot] = useState("");
  const [selectedDate, setSelectedDate] = useState("");
  const [reason, setReason] = useState("");
  const [booking, setBooking] = useState(false);

  useEffect(() => {
    const load = async () => {
      try {
        const { data } = await api.get(`/doctors/${id}`);
        setDoctor(data.doctor);
        setReviews(data.reviews);
        if (data.doctor.availability.length > 0) {
          setSelectedDay(data.doctor.availability[0].day);
        }
      } catch (err) {
        toast.error("Doctor not found");
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [id]);

  const dayAvailability = doctor?.availability.find((a) => a.day === selectedDay);

  // Compute the next calendar date matching the selected weekday
  const getNextDateForDay = (dayName) => {
    const days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    const targetIdx = days.indexOf(dayName);
    const today = new Date();
    const diff = (targetIdx - today.getDay() + 7) % 7;
    const result = new Date(today);
    result.setDate(today.getDate() + diff);
    return result;
  };

  useEffect(() => {
    if (selectedDay) {
      const date = getNextDateForDay(selectedDay);
      setSelectedDate(date.toISOString().split("T")[0]);
      setSelectedSlot("");
    }
  }, [selectedDay]);

  const handleBook = async () => {
    if (!user) {
      toast.error("Please login to book an appointment");
      navigate("/login");
      return;
    }
    if (user.role !== "patient") {
      toast.error("Only patients can book appointments");
      return;
    }
    if (!selectedSlot) {
      toast.error("Please select a time slot");
      return;
    }

    setBooking(true);
    try {
      await api.post("/patients/appointments", {
        doctorId: id,
        date: selectedDate,
        timeSlot: selectedSlot,
        reason,
      });
      toast.success("Appointment booked successfully!");
      navigate("/patient/appointments");
    } catch (err) {
      toast.error(err.response?.data?.message || "Failed to book appointment");
    } finally {
      setBooking(false);
    }
  };

  if (loading) return <Spinner fullScreen />;
  if (!doctor) return <p className="text-center py-20">Doctor not found.</p>;

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-10 grid md:grid-cols-3 gap-8">
      {/* Left: profile */}
      <div className="md:col-span-2 space-y-6">
        <div className="card p-6 flex flex-col sm:flex-row gap-6">
          <img
            src={doctor.photo?.url || "https://placehold.co/200x200?text=Doctor"}
            alt={doctor.name}
            className="w-32 h-32 rounded-xl object-cover mx-auto sm:mx-0"
          />
          <div>
            <h1 className="text-2xl font-bold">Dr. {doctor.name}</h1>
            <p className="text-primary-600 font-medium">{doctor.specialization}</p>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">{doctor.qualification}</p>
            <div className="flex flex-wrap gap-4 mt-3 text-sm text-gray-600 dark:text-gray-300">
              <span className="flex items-center gap-1"><FiStar className="text-yellow-500" /> {doctor.rating || "New"} ({doctor.numReviews} reviews)</span>
              <span className="flex items-center gap-1"><FiMapPin /> {doctor.hospital}</span>
              <span className="flex items-center gap-1"><FiClock /> {doctor.experience}+ yrs exp</span>
            </div>
            {doctor.languages?.length > 0 && (
              <p className="flex items-center gap-1 text-sm text-gray-500 dark:text-gray-400 mt-2">
                <FiGlobe /> {doctor.languages.join(", ")}
              </p>
            )}
          </div>
        </div>

        <div className="card p-6">
          <h2 className="font-semibold mb-2">About</h2>
          <p className="text-sm text-gray-600 dark:text-gray-300">{doctor.about || "No description provided."}</p>
        </div>

        <div className="card p-6">
          <h2 className="font-semibold mb-4">Patient Reviews ({reviews.length})</h2>
          {reviews.length === 0 ? (
            <p className="text-sm text-gray-500">No reviews yet.</p>
          ) : (
            <div className="space-y-4">
              {reviews.map((r) => (
                <div key={r._id} className="border-b border-gray-100 dark:border-gray-800 pb-3 last:border-0">
                  <div className="flex items-center justify-between">
                    <p className="font-medium text-sm">{r.patient?.name || "Anonymous"}</p>
                    <span className="flex items-center gap-1 text-xs text-yellow-500"><FiStar className="fill-current" /> {r.rating}</span>
                  </div>
                  <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">{r.comment}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Right: booking */}
      <div className="card p-6 h-fit sticky top-20">
        <h2 className="font-semibold mb-4 flex items-center gap-2"><FiCalendar /> Book Appointment</h2>
        <p className="text-sm text-gray-500 mb-4">Consultation Fee: <span className="font-semibold text-gray-800 dark:text-white">₹{doctor.consultationFee}</span></p>

        <label className="text-sm font-medium">Select Day</label>
        <select value={selectedDay} onChange={(e) => setSelectedDay(e.target.value)} className="input-field mt-1 mb-4">
          {doctor.availability.length === 0 && <option value="">No availability set</option>}
          {doctor.availability.map((a) => (
            <option key={a.day} value={a.day}>{a.day}</option>
          ))}
        </select>

        <label className="text-sm font-medium">Select Time Slot</label>
        <div className="grid grid-cols-3 gap-2 mt-1 mb-4">
          {dayAvailability?.slots.map((slot) => (
            <button
              key={slot}
              onClick={() => setSelectedSlot(slot)}
              className={`text-xs py-2 rounded-lg border ${
                selectedSlot === slot
                  ? "bg-primary-600 text-white border-primary-600"
                  : "border-gray-200 dark:border-gray-700 hover:bg-gray-100 dark:hover:bg-gray-800"
              }`}
            >
              {slot}
            </button>
          ))}
          {(!dayAvailability || dayAvailability.slots.length === 0) && (
            <p className="col-span-3 text-xs text-gray-500">No slots available on this day.</p>
          )}
        </div>

        <label className="text-sm font-medium">Reason for Visit (optional)</label>
        <textarea
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          rows={3}
          className="input-field mt-1 mb-4"
          placeholder="Briefly describe your symptoms..."
        />

        <button onClick={handleBook} disabled={booking} className="btn-primary w-full">
          {booking ? "Booking..." : "Confirm Appointment"}
        </button>
      </div>
    </div>
  );
};

export default DoctorDetails;
