import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { FiSearch, FiCalendar, FiUserCheck, FiHeart } from "react-icons/fi";
import api from "../api/axios";
import DoctorCard from "../components/patient/DoctorCard";
import Spinner from "../components/common/Spinner";

const specializationIcons = ["🩺", "❤️", "🧴", "🧠", "🦴", "👶", "🦷", "👂", "🤰", "🧘"];

const Home = () => {
  const [doctors, setDoctors] = useState([]);
  const [specializations, setSpecializations] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        const [docRes, specRes] = await Promise.all([
          api.get("/doctors?limit=4&sort=-rating"),
          api.get("/doctors/specializations"),
        ]);
        setDoctors(docRes.data.doctors);
        setSpecializations(specRes.data.specializations);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  return (
    <div>
      {/* Hero */}
      <section className="bg-gradient-to-br from-primary-600 to-primary-800 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 grid md:grid-cols-2 gap-10 items-center">
          <div>
            <h1 className="text-4xl md:text-5xl font-bold leading-tight">
              Book Trusted Doctors, <span className="text-primary-200">Anytime, Anywhere</span>
            </h1>
            <p className="mt-4 text-primary-100">
              Search verified doctors by specialization, check live availability, and book your
              appointment in under a minute.
            </p>
            <div className="mt-6 flex gap-3">
              <Link to="/doctors" className="bg-white text-primary-700 font-semibold px-6 py-3 rounded-lg hover:bg-primary-50 flex items-center gap-2">
                <FiSearch /> Find a Doctor
              </Link>
              <Link to="/register" className="border border-white/60 px-6 py-3 rounded-lg hover:bg-white/10">
                Create Account
              </Link>
            </div>
          </div>
          <img
            src="https://placehold.co/600x400?text=Book+A+Doctor"
            alt="Doctor consultation"
            className="rounded-2xl shadow-2xl w-full"
          />
        </div>
      </section>

      {/* How it works */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <h2 className="text-2xl font-bold text-center mb-10">How It Works</h2>
        <div className="grid sm:grid-cols-3 gap-8">
          {[
            { icon: <FiSearch className="text-3xl text-primary-600" />, title: "Search", desc: "Browse doctors by name or specialization." },
            { icon: <FiCalendar className="text-3xl text-primary-600" />, title: "Book", desc: "Pick a convenient time slot instantly." },
            { icon: <FiUserCheck className="text-3xl text-primary-600" />, title: "Consult", desc: "Get confirmed and visit your doctor." },
          ].map((step) => (
            <div key={step.title} className="card p-6 text-center">
              <div className="flex justify-center mb-3">{step.icon}</div>
              <h3 className="font-semibold mb-1">{step.title}</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400">{step.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Specializations */}
      <section className="bg-white dark:bg-gray-900 py-16 border-y border-gray-100 dark:border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl font-bold text-center mb-10">Browse by Specialization</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4">
            {specializations.map((spec, i) => (
              <Link
                key={spec}
                to={`/doctors?specialization=${encodeURIComponent(spec)}`}
                className="card p-4 text-center hover:shadow-md hover:-translate-y-0.5 transition-all"
              >
                <div className="text-2xl mb-2">{specializationIcons[i % specializationIcons.length]}</div>
                <p className="text-sm font-medium">{spec}</p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Top doctors */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="flex items-center justify-between mb-10">
          <h2 className="text-2xl font-bold">Top Rated Doctors</h2>
          <Link to="/doctors" className="text-primary-600 text-sm font-medium">View all →</Link>
        </div>
        {loading ? (
          <Spinner fullScreen />
        ) : (
          <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-6">
            {doctors.map((doc) => (
              <DoctorCard key={doc._id} doctor={doc} />
            ))}
          </div>
        )}
      </section>

      {/* CTA */}
      <section className="bg-primary-600 text-white py-16 text-center">
        <FiHeart className="text-4xl mx-auto mb-4" />
        <h2 className="text-2xl font-bold">Your Health, Our Priority</h2>
        <p className="text-primary-100 mt-2">Join thousands who trust BookADoctor for their healthcare needs.</p>
        <Link to="/register" className="inline-block mt-6 bg-white text-primary-700 font-semibold px-6 py-3 rounded-lg hover:bg-primary-50">
          Get Started
        </Link>
      </section>
    </div>
  );
};

export default Home;
