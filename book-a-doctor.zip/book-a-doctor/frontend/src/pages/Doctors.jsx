import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { FiSearch } from "react-icons/fi";
import api from "../api/axios";
import DoctorCard from "../components/patient/DoctorCard";
import Spinner from "../components/common/Spinner";
import Pagination from "../components/common/Pagination";

const Doctors = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [doctors, setDoctors] = useState([]);
  const [specializations, setSpecializations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [pageInfo, setPageInfo] = useState({ page: 1, pages: 1 });

  const search = searchParams.get("search") || "";
  const specialization = searchParams.get("specialization") || "";
  const page = Number(searchParams.get("page")) || 1;

  useEffect(() => {
    api.get("/doctors/specializations").then((res) => setSpecializations(res.data.specializations));
  }, []);

  useEffect(() => {
    const fetchDoctors = async () => {
      setLoading(true);
      try {
        const params = new URLSearchParams();
        if (search) params.set("search", search);
        if (specialization) params.set("specialization", specialization);
        params.set("page", page);
        params.set("limit", 9);

        const { data } = await api.get(`/doctors?${params.toString()}`);
        setDoctors(data.doctors);
        setPageInfo({ page: data.page, pages: data.pages });
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchDoctors();
  }, [search, specialization, page]);

  const updateParam = (key, value) => {
    const next = new URLSearchParams(searchParams);
    if (value) next.set(key, value);
    else next.delete(key);
    next.set("page", 1);
    setSearchParams(next);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <h1 className="text-2xl font-bold mb-6">Find Your Doctor</h1>

      {/* Filters */}
      <div className="flex flex-col md:flex-row gap-4 mb-8">
        <div className="relative flex-1">
          <FiSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            defaultValue={search}
            placeholder="Search doctors by name..."
            onChange={(e) => updateParam("search", e.target.value)}
            className="input-field pl-10"
          />
        </div>
        <select
          value={specialization}
          onChange={(e) => updateParam("specialization", e.target.value)}
          className="input-field md:w-64"
        >
          <option value="">All Specializations</option>
          {specializations.map((spec) => (
            <option key={spec} value={spec}>{spec}</option>
          ))}
        </select>
      </div>

      {loading ? (
        <Spinner fullScreen />
      ) : doctors.length === 0 ? (
        <p className="text-center text-gray-500 py-20">No doctors found matching your criteria.</p>
      ) : (
        <>
          <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-6">
            {doctors.map((doc) => (
              <DoctorCard key={doc._id} doctor={doc} />
            ))}
          </div>
          <Pagination page={pageInfo.page} pages={pageInfo.pages} onPageChange={(p) => updateParam("page", p)} />
        </>
      )}
    </div>
  );
};

export default Doctors;
