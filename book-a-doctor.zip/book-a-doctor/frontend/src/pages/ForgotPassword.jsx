import { useState } from "react";
import { useLocation, Link } from "react-router-dom";
import toast from "react-hot-toast";
import api from "../api/axios";

const ForgotPassword = () => {
  const location = useLocation();
  const role = new URLSearchParams(location.search).get("role") || "patient";

  const [step, setStep] = useState(1); // 1: request token, 2: reset password
  const [email, setEmail] = useState("");
  const [token, setToken] = useState("");
  const [passwords, setPasswords] = useState({ password: "", confirmPassword: "" });
  const [loading, setLoading] = useState(false);

  const requestReset = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const { data } = await api.post("/auth/forgot-password", { email, role });
      // Demo project: token returned directly instead of emailed
      setToken(data.resetToken);
      toast.success("Reset token generated. Enter your new password below.");
      setStep(2);
    } catch (err) {
      toast.error(err.response?.data?.message || "Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  const resetPassword = async (e) => {
    e.preventDefault();
    if (passwords.password !== passwords.confirmPassword) {
      toast.error("Passwords do not match");
      return;
    }
    setLoading(true);
    try {
      await api.put(`/auth/reset-password/${token}`, { password: passwords.password, role });
      toast.success("Password reset! Please login.");
      setStep(3);
    } catch (err) {
      toast.error(err.response?.data?.message || "Reset failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4">
      <div className="card w-full max-w-md p-8">
        <h1 className="text-2xl font-bold text-center mb-6">Reset Password</h1>

        {step === 1 && (
          <form onSubmit={requestReset} className="space-y-4">
            <div>
              <label className="text-sm font-medium">Email</label>
              <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} className="input-field mt-1" placeholder="you@example.com" />
            </div>
            <button disabled={loading} className="btn-primary w-full">
              {loading ? "Sending..." : "Send Reset Link"}
            </button>
          </form>
        )}

        {step === 2 && (
          <form onSubmit={resetPassword} className="space-y-4">
            <div>
              <label className="text-sm font-medium">New Password</label>
              <input type="password" required value={passwords.password} onChange={(e) => setPasswords({ ...passwords, password: e.target.value })} className="input-field mt-1" />
            </div>
            <div>
              <label className="text-sm font-medium">Confirm Password</label>
              <input type="password" required value={passwords.confirmPassword} onChange={(e) => setPasswords({ ...passwords, confirmPassword: e.target.value })} className="input-field mt-1" />
            </div>
            <button disabled={loading} className="btn-primary w-full">
              {loading ? "Resetting..." : "Reset Password"}
            </button>
          </form>
        )}

        {step === 3 && (
          <div className="text-center">
            <p className="text-sm text-gray-500 mb-4">Your password has been reset successfully.</p>
            <Link to="/login" className="btn-primary inline-block">Go to Login</Link>
          </div>
        )}
      </div>
    </div>
  );
};

export default ForgotPassword;
