import { useState } from "react";
import toast from "react-hot-toast";
import { FiMail, FiPhone, FiMapPin } from "react-icons/fi";

const Contact = () => {
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [submitting, setSubmitting] = useState(false);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.message) {
      toast.error("Please fill in all fields");
      return;
    }
    setSubmitting(true);
    // Placeholder: in production wire this to a real contact/support endpoint.
    setTimeout(() => {
      toast.success("Message sent! We'll get back to you soon.");
      setForm({ name: "", email: "", message: "" });
      setSubmitting(false);
    }, 800);
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-16 grid md:grid-cols-2 gap-12">
      <div>
        <h1 className="text-3xl font-bold mb-4">Get in Touch</h1>
        <p className="text-gray-500 dark:text-gray-400 mb-8">
          Have questions about booking, doctors, or partnerships? Reach out to us.
        </p>
        <div className="space-y-4 text-sm">
          <p className="flex items-center gap-3"><FiMail className="text-primary-600" /> support@bookadoctor.com</p>
          <p className="flex items-center gap-3"><FiPhone className="text-primary-600" /> +91 98765 43210</p>
          <p className="flex items-center gap-3"><FiMapPin className="text-primary-600" /> Bengaluru, India</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="card p-6 space-y-4">
        <div>
          <label className="text-sm font-medium">Name</label>
          <input name="name" value={form.name} onChange={handleChange} className="input-field mt-1" placeholder="Your name" />
        </div>
        <div>
          <label className="text-sm font-medium">Email</label>
          <input name="email" type="email" value={form.email} onChange={handleChange} className="input-field mt-1" placeholder="you@example.com" />
        </div>
        <div>
          <label className="text-sm font-medium">Message</label>
          <textarea name="message" rows={4} value={form.message} onChange={handleChange} className="input-field mt-1" placeholder="How can we help?" />
        </div>
        <button disabled={submitting} className="btn-primary w-full">
          {submitting ? "Sending..." : "Send Message"}
        </button>
      </form>
    </div>
  );
};

export default Contact;
