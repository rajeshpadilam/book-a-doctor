import { useState } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import toast from "react-hot-toast";
import { useAuth } from "../context/AuthContext";

const roleRedirect = { patient: "/patient/dashboard", doctor: "/doctor/dashboard", admin: "/admin/dashboard" };

const Login = () => {
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  // Default role can be pre-selected via ?role=doctor in the URL
  const params = new URLSearchParams(location.search);
  const initialRole = params.get("role") || "patient";

  const [form, setForm] = useState({ email: "", password: "" });
  const [role, setRole] = useState(initialRole);
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const user = await login(form.email, form.password, role);
      navigate(roleRedirect[user.role] || "/");
    } catch (err) {
      toast.error(err.response?.data?.message || "Login failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4">
      <div className="card w-full max-w-md p-8">
        <h1 className="text-2xl font-bold text-center mb-1">Welcome Back</h1>
        <p className="text-center text-sm text-gray-500 dark:text-gray-400 mb-6">Login to continue</p>

        <div className="flex gap-2 mb-6">
          {["patient", "doctor", "admin"].map((r) => (
            <button
              key={r}
              type="button"
              onClick={() => setRole(r)}
              className={`flex-1 text-sm py-2 rounded-lg border capitalize ${
                role === r
                  ? "bg-primary-600 text-white border-primary-600"
                  : "border-gray-200 dark:border-gray-700"
              }`}
            >
              {r}
            </button>
          ))}
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-sm font-medium">Email</label>
            <input name="email" type="email" required value={form.email} onChange={handleChange} className="input-field mt-1" placeholder="you@example.com" />
          </div>
          <div>
            <div className="flex justify-between">
              <label className="text-sm font-medium">Password</label>
              <Link to={`/forgot-password?role=${role}`} className="text-xs text-primary-600">Forgot password?</Link>
            </div>
            <input name="password" type="password" required value={form.password} onChange={handleChange} className="input-field mt-1" placeholder="••••••••" />
          </div>
          <button disabled={loading} className="btn-primary w-full">
            {loading ? "Logging in..." : "Login"}
          </button>
        </form>

        {role === "patient" && (
          <p className="text-center text-sm text-gray-500 dark:text-gray-400 mt-6">
            Don't have an account? <Link to="/register" className="text-primary-600 font-medium">Sign up</Link>
          </p>
        )}
      </div>
    </div>
  );
};

export default Login;
