import { useEffect, useState } from "react";
import api from "../../api/axios";
import Spinner from "../../components/common/Spinner";
import Pagination from "../../components/common/Pagination";

const statusColors = {
  pending: "bg-yellow-100 text-yellow-700",
  accepted: "bg-blue-100 text-blue-700",
  completed: "bg-green-100 text-green-700",
  rejected: "bg-red-100 text-red-700",
  cancelled: "bg-gray-100 text-gray-700",
};

const filters = ["all", "pending", "accepted", "completed", "cancelled", "rejected"];

const AdminAppointments = () => {
  const [appointments, setAppointments] = useState([]);
  const [status, setStatus] = useState("all");
  const [loading, setLoading] = useState(true);
  const [pageInfo, setPageInfo] = useState({ page: 1, pages: 1 });

  const fetchAppointments = async (page = 1) => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ page, limit: 10 });
      if (status !== "all") params.set("status", status);
      const { data } = await api.get(`/admin/appointments?${params.toString()}`);
      setAppointments(data.appointments);
      setPageInfo({ page: data.page, pages: data.pages });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAppointments(1);
  }, [status]);

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">All Appointments</h1>

      <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
        {filters.map((f) => (
          <button
            key={f}
            onClick={() => setStatus(f)}
            className={`text-xs px-3 py-1.5 rounded-full capitalize whitespace-nowrap border ${
              status === f ? "bg-primary-600 text-white border-primary-600" : "border-gray-200 dark:border-gray-700"
            }`}
          >
            {f}
          </button>
        ))}
      </div>

      {loading ? (
        <Spinner fullScreen />
      ) : (
        <>
          <div className="card overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-50 dark:bg-gray-800 text-left">
                <tr>
                  <th className="p-3">Patient</th>
                  <th className="p-3">Doctor</th>
                  <th className="p-3">Date / Time</th>
                  <th className="p-3">Fee</th>
                  <th className="p-3">Status</th>
                </tr>
              </thead>
              <tbody>
                {appointments.map((a) => (
                  <tr key={a._id} className="border-t border-gray-100 dark:border-gray-800">
                    <td className="p-3">{a.patient?.name}</td>
                    <td className="p-3">Dr. {a.doctor?.name} <span className="text-xs text-gray-500">({a.doctor?.specialization})</span></td>
                    <td className="p-3">{new Date(a.date).toLocaleDateString()} · {a.timeSlot}</td>
                    <td className="p-3">₹{a.consultationFee}</td>
                    <td className="p-3"><span className={`text-xs px-2 py-1 rounded-full capitalize ${statusColors[a.status]}`}>{a.status}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <Pagination page={pageInfo.page} pages={pageInfo.pages} onPageChange={fetchAppointments} />
        </>
      )}
    </div>
  );
};

export default AdminAppointments;
