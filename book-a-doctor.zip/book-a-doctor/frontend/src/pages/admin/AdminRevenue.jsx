import { useEffect, useState } from "react";
import api from "../../api/axios";
import Spinner from "../../components/common/Spinner";

const MONTHS = ["", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

const AdminRevenue = () => {
  const [revenue, setRevenue] = useState([]);
  const [specStats, setSpecStats] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([api.get("/admin/revenue"), api.get("/admin/specializations")]).then(
      ([revRes, specRes]) => {
        setRevenue(revRes.data.revenue);
        setSpecStats(specRes.data.stats);
      }
    ).finally(() => setLoading(false));
  }, []);

  if (loading) return <Spinner fullScreen />;

  const maxTotal = Math.max(...revenue.map((r) => r.total), 1);
  const totalRevenue = revenue.reduce((sum, r) => sum + r.total, 0);

  return (
    <div>
      <h1 className="text-2xl font-bold mb-2">Revenue Report</h1>
      <p className="text-gray-500 dark:text-gray-400 mb-8">
        Total revenue from completed appointments: <span className="font-semibold text-gray-800 dark:text-white">₹{totalRevenue}</span>
      </p>

      <div className="card p-6 mb-8">
        <h2 className="font-semibold mb-6">Monthly Revenue</h2>
        {revenue.length === 0 ? (
          <p className="text-sm text-gray-500">No revenue data yet.</p>
        ) : (
          <div className="flex items-end gap-4 h-48">
            {revenue.map((r) => (
              <div key={`${r._id.year}-${r._id.month}`} className="flex-1 flex flex-col items-center justify-end h-full">
                <span className="text-xs font-medium mb-1">₹{r.total}</span>
                <div
                  className="w-full bg-primary-500 rounded-t-md"
                  style={{ height: `${(r.total / maxTotal) * 100}%`, minHeight: "4px" }}
                />
                <span className="text-xs text-gray-500 mt-2">{MONTHS[r._id.month]} {r._id.year}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="card p-6">
        <h2 className="font-semibold mb-4">Doctors by Specialization</h2>
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-4">
          {specStats.map((s) => (
            <div key={s._id} className="text-center p-3 rounded-lg bg-gray-50 dark:bg-gray-800">
              <p className="text-lg font-bold">{s.doctorCount}</p>
              <p className="text-xs text-gray-500">{s._id}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AdminRevenue;
