import { useEffect, useState } from "react";
import { FiUserPlus, FiUsers, FiCalendar, FiDollarSign } from "react-icons/fi";
import api from "../../api/axios";
import Spinner from "../../components/common/Spinner";

const AdminDashboard = () => {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get("/admin/dashboard").then((res) => setStats(res.data.stats)).finally(() => setLoading(false));
  }, []);

  if (loading || !stats) return <Spinner fullScreen />;

  const cards = [
    { label: "Total Doctors", value: stats.totalDoctors, icon: <FiUserPlus />, className: "bg-primary-100 text-primary-600 dark:bg-primary-900" },
    { label: "Total Patients", value: stats.totalPatients, icon: <FiUsers />, className: "bg-blue-100 text-blue-600 dark:bg-blue-900" },
    { label: "Total Appointments", value: stats.totalAppointments, icon: <FiCalendar />, className: "bg-yellow-100 text-yellow-600 dark:bg-yellow-900" },
    { label: "Total Revenue", value: `₹${stats.totalRevenue}`, icon: <FiDollarSign />, className: "bg-green-100 text-green-600 dark:bg-green-900" },
  ];

  return (
    <div>
      <h1 className="text-2xl font-bold mb-8">Admin Dashboard</h1>

      <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-4 mb-10">
        {cards.map((c) => (
          <div key={c.label} className="card p-5 flex items-center gap-4">
            <div className={`p-3 rounded-lg ${c.className}`}>{c.icon}</div>
            <div>
              <p className="text-xl font-bold">{c.value}</p>
              <p className="text-xs text-gray-500">{c.label}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="card p-6">
        <h2 className="font-semibold mb-4">Appointments by Status</h2>
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-4">
          {["pending", "accepted", "completed", "rejected", "cancelled"].map((status) => (
            <div key={status} className="text-center p-3 rounded-lg bg-gray-50 dark:bg-gray-800">
              <p className="text-lg font-bold">{stats.appointmentsByStatus[status] || 0}</p>
              <p className="text-xs text-gray-500 capitalize">{status}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
