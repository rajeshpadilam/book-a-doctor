import { useEffect, useState } from "react";
import toast from "react-hot-toast";
import { FiSearch, FiPlus, FiEdit2, FiTrash2, FiToggleLeft, FiToggleRight, FiX } from "react-icons/fi";
import api from "../../api/axios";
import Spinner from "../../components/common/Spinner";
import Pagination from "../../components/common/Pagination";

const SPECIALIZATIONS = [
  "General Physician", "Cardiologist", "Dermatologist", "Neurologist", "Orthopedic",
  "Pediatrician", "Dentist", "ENT", "Gynecologist", "Psychiatrist",
];

const emptyForm = {
  name: "", email: "", password: "", phone: "", qualification: "", experience: 0,
  specialization: SPECIALIZATIONS[0], hospital: "", consultationFee: 0, languages: "", about: "",
};

const AdminDoctors = () => {
  const [doctors, setDoctors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [specialization, setSpecialization] = useState("");
  const [pageInfo, setPageInfo] = useState({ page: 1, pages: 1 });

  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [form, setForm] = useState(emptyForm);
  const [photoFile, setPhotoFile] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  const fetchDoctors = async (page = 1) => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ page, limit: 8 });
      if (search) params.set("search", search);
      if (specialization) params.set("specialization", specialization);
      const { data } = await api.get(`/admin/doctors?${params.toString()}`);
      setDoctors(data.doctors);
      setPageInfo({ page: data.page, pages: data.pages });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDoctors(1);
  }, [search, specialization]);

  const openAddModal = () => {
    setEditingId(null);
    setForm(emptyForm);
    setPhotoFile(null);
    setShowModal(true);
  };

  const openEditModal = (doc) => {
    setEditingId(doc._id);
    setForm({
      name: doc.name, email: doc.email, password: "", phone: doc.phone || "",
      qualification: doc.qualification, experience: doc.experience, specialization: doc.specialization,
      hospital: doc.hospital, consultationFee: doc.consultationFee, languages: (doc.languages || []).join(", "),
      about: doc.about || "",
    });
    setPhotoFile(null);
    setShowModal(true);
  };

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const fd = new FormData();
      Object.entries(form).forEach(([key, value]) => {
        if (key === "languages") {
          fd.append("languages", JSON.stringify(value.split(",").map((l) => l.trim()).filter(Boolean)));
        } else if (key === "password" && !value) {
          // skip empty password on edit
        } else {
          fd.append(key, value);
        }
      });
      if (photoFile) fd.append("photo", photoFile);

      if (editingId) {
        await api.put(`/admin/doctors/${editingId}`, fd, { headers: { "Content-Type": "multipart/form-data" } });
        toast.success("Doctor updated successfully");
      } else {
        await api.post("/admin/doctors", fd, { headers: { "Content-Type": "multipart/form-data" } });
        toast.success("Doctor added successfully");
      }
      setShowModal(false);
      fetchDoctors(pageInfo.page);
    } catch (err) {
      toast.error(err.response?.data?.message || "Operation failed");
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Delete this doctor permanently?")) return;
    try {
      await api.delete(`/admin/doctors/${id}`);
      toast.success("Doctor deleted");
      fetchDoctors(pageInfo.page);
    } catch (err) {
      toast.error(err.response?.data?.message || "Delete failed");
    }
  };

  const toggleStatus = async (id) => {
    try {
      await api.put(`/admin/doctors/${id}/status`);
      fetchDoctors(pageInfo.page);
    } catch (err) {
      toast.error("Failed to update status");
    }
  };

  return (
    <div>
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
        <h1 className="text-2xl font-bold">Manage Doctors</h1>
        <button onClick={openAddModal} className="btn-primary flex items-center gap-2 text-sm w-fit">
          <FiPlus /> Add Doctor
        </button>
      </div>

      <div className="flex flex-col md:flex-row gap-4 mb-6">
        <div className="relative flex-1">
          <FiSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input placeholder="Search by name..." value={search} onChange={(e) => setSearch(e.target.value)} className="input-field pl-10" />
        </div>
        <select value={specialization} onChange={(e) => setSpecialization(e.target.value)} className="input-field md:w-64">
          <option value="">All Specializations</option>
          {SPECIALIZATIONS.map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
      </div>

      {loading ? (
        <Spinner fullScreen />
      ) : (
        <>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {doctors.map((doc) => (
              <div key={doc._id} className="card p-4">
                <div className="flex items-center gap-3 mb-3">
                  <img src={doc.photo?.url || "https://placehold.co/60"} alt="" className="w-14 h-14 rounded-lg object-cover" />
                  <div>
                    <p className="font-medium text-sm">Dr. {doc.name}</p>
                    <p className="text-xs text-primary-600">{doc.specialization}</p>
                    <p className="text-xs text-gray-500">{doc.hospital}</p>
                  </div>
                </div>
                <div className="flex items-center justify-between text-xs text-gray-500 mb-3">
                  <span>₹{doc.consultationFee} · {doc.experience} yrs</span>
                  <span className={doc.isActive ? "text-green-600" : "text-red-500"}>
                    {doc.isActive ? "Active" : "Inactive"}
                  </span>
                </div>
                <div className="flex gap-2">
                  <button onClick={() => openEditModal(doc)} className="flex-1 text-xs btn-outline py-1.5 flex items-center justify-center gap-1">
                    <FiEdit2 /> Edit
                  </button>
                  <button onClick={() => toggleStatus(doc._id)} className="flex-1 text-xs btn-outline py-1.5 flex items-center justify-center gap-1">
                    {doc.isActive ? <FiToggleRight /> : <FiToggleLeft />} {doc.isActive ? "Disable" : "Enable"}
                  </button>
                  <button onClick={() => handleDelete(doc._id)} className="text-xs border border-red-200 text-red-600 px-3 py-1.5 rounded-lg">
                    <FiTrash2 />
                  </button>
                </div>
              </div>
            ))}
          </div>
          <Pagination page={pageInfo.page} pages={pageInfo.pages} onPageChange={fetchDoctors} />
        </>
      )}

      {/* Add / Edit Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="card w-full max-w-2xl p-6 my-8">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-bold">{editingId ? "Edit Doctor" : "Add Doctor"}</h2>
              <button onClick={() => setShowModal(false)}><FiX /></button>
            </div>
            <form onSubmit={handleSubmit} className="space-y-4 max-h-[70vh] overflow-y-auto pr-1">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-sm font-medium">Name</label>
                  <input name="name" required value={form.name} onChange={handleChange} className="input-field mt-1" />
                </div>
                <div>
                  <label className="text-sm font-medium">Email</label>
                  <input name="email" type="email" required value={form.email} onChange={handleChange} className="input-field mt-1" disabled={!!editingId} />
                </div>
              </div>
              {!editingId && (
                <div>
                  <label className="text-sm font-medium">Password</label>
                  <input name="password" type="password" required value={form.password} onChange={handleChange} className="input-field mt-1" />
                </div>
              )}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-sm font-medium">Phone</label>
                  <input name="phone" value={form.phone} onChange={handleChange} className="input-field mt-1" />
                </div>
                <div>
                  <label className="text-sm font-medium">Experience (years)</label>
                  <input type="number" name="experience" value={form.experience} onChange={handleChange} className="input-field mt-1" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-sm font-medium">Qualification</label>
                  <input name="qualification" required value={form.qualification} onChange={handleChange} className="input-field mt-1" />
                </div>
                <div>
                  <label className="text-sm font-medium">Specialization</label>
                  <select name="specialization" value={form.specialization} onChange={handleChange} className="input-field mt-1">
                    {SPECIALIZATIONS.map((s) => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-sm font-medium">Hospital</label>
                  <input name="hospital" required value={form.hospital} onChange={handleChange} className="input-field mt-1" />
                </div>
                <div>
                  <label className="text-sm font-medium">Consultation Fee (₹)</label>
                  <input type="number" name="consultationFee" value={form.consultationFee} onChange={handleChange} className="input-field mt-1" />
                </div>
              </div>
              <div>
                <label className="text-sm font-medium">Languages (comma separated)</label>
                <input name="languages" value={form.languages} onChange={handleChange} className="input-field mt-1" placeholder="English, Hindi" />
              </div>
              <div>
                <label className="text-sm font-medium">About</label>
                <textarea name="about" value={form.about} onChange={handleChange} rows={3} className="input-field mt-1" />
              </div>
              <div>
                <label className="text-sm font-medium">Photo</label>
                <input type="file" accept="image/*" onChange={(e) => setPhotoFile(e.target.files[0])} className="input-field mt-1" />
              </div>
              <button disabled={submitting} className="btn-primary w-full">
                {submitting ? "Saving..." : editingId ? "Update Doctor" : "Add Doctor"}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminDoctors;
