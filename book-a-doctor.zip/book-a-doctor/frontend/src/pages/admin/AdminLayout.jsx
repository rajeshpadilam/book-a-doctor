import { Outlet } from "react-router-dom";
import { FiGrid, FiUserPlus, FiUsers, FiCalendar, FiDollarSign } from "react-icons/fi";
import DashboardSidebar from "../../components/common/DashboardSidebar";

const links = [
  { name: "Dashboard", path: "/admin/dashboard", icon: <FiGrid /> },
  { name: "Doctors", path: "/admin/doctors", icon: <FiUserPlus /> },
  { name: "Patients", path: "/admin/patients", icon: <FiUsers /> },
  { name: "Appointments", path: "/admin/appointments", icon: <FiCalendar /> },
  { name: "Revenue", path: "/admin/revenue", icon: <FiDollarSign /> },
];

const AdminLayout = () => {
  return (
    <div className="flex flex-col md:flex-row">
      <DashboardSidebar links={links} title="Admin Panel" />
      <main className="flex-1 p-4 sm:p-6 lg:p-8">
        <Outlet />
      </main>
    </div>
  );
};

export default AdminLayout;
