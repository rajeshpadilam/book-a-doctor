import { useEffect, useState } from "react";
import toast from "react-hot-toast";
import { FiSearch, FiTrash2 } from "react-icons/fi";
import api from "../../api/axios";
import Spinner from "../../components/common/Spinner";
import Pagination from "../../components/common/Pagination";

const AdminPatients = () => {
  const [patients, setPatients] = useState([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [pageInfo, setPageInfo] = useState({ page: 1, pages: 1 });

  const fetchPatients = async (page = 1) => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ page, limit: 10 });
      if (search) params.set("search", search);
      const { data } = await api.get(`/admin/patients?${params.toString()}`);
      setPatients(data.patients);
      setPageInfo({ page: data.page, pages: data.pages });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPatients(1);
  }, [search]);

  const handleDelete = async (id) => {
    if (!window.confirm("Remove this patient account permanently?")) return;
    try {
      await api.delete(`/admin/patients/${id}`);
      toast.success("Patient removed");
      fetchPatients(pageInfo.page);
    } catch (err) {
      toast.error(err.response?.data?.message || "Delete failed");
    }
  };

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Manage Patients</h1>

      <div className="relative mb-6 max-w-md">
        <FiSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
        <input placeholder="Search by name..." value={search} onChange={(e) => setSearch(e.target.value)} className="input-field pl-10" />
      </div>

      {loading ? (
        <Spinner fullScreen />
      ) : (
        <>
          <div className="card overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-50 dark:bg-gray-800 text-left">
                <tr>
                  <th className="p-3">Name</th>
                  <th className="p-3">Email</th>
                  <th className="p-3">Phone</th>
                  <th className="p-3">Joined</th>
                  <th className="p-3"></th>
                </tr>
              </thead>
              <tbody>
                {patients.map((p) => (
                  <tr key={p._id} className="border-t border-gray-100 dark:border-gray-800">
                    <td className="p-3 flex items-center gap-2">
                      <img src={p.profileImage?.url || "https://placehold.co/32"} alt="" className="w-8 h-8 rounded-full object-cover" />
                      {p.name}
                    </td>
                    <td className="p-3">{p.email}</td>
                    <td className="p-3">{p.phone || "-"}</td>
                    <td className="p-3">{new Date(p.createdAt).toLocaleDateString()}</td>
                    <td className="p-3">
                      <button onClick={() => handleDelete(p._id)} className="text-red-500 hover:text-red-700"><FiTrash2 /></button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <Pagination page={pageInfo.page} pages={pageInfo.pages} onPageChange={fetchPatients} />
        </>
      )}
    </div>
  );
};

export default AdminPatients;
