import { Link } from "react-router-dom";
import { FiStar, FiMapPin } from "react-icons/fi";

const DoctorCard = ({ doctor }) => {
  return (
    <div className="card overflow-hidden hover:shadow-lg transition-shadow group">
      <div className="h-48 bg-gray-100 dark:bg-gray-700 overflow-hidden">
        <img
          src={doctor.photo?.url || "https://placehold.co/400x300?text=Doctor"}
          alt={doctor.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
      </div>
      <div className="p-4">
        <div className="flex items-start justify-between">
          <div>
            <h3 className="font-semibold text-gray-900 dark:text-white">Dr. {doctor.name}</h3>
            <p className="text-sm text-primary-600">{doctor.specialization}</p>
          </div>
          <div className="flex items-center gap-1 text-sm text-yellow-500">
            <FiStar className="fill-current" /> {doctor.rating || "New"}
          </div>
        </div>
        <p className="flex items-center gap-1 text-xs text-gray-500 dark:text-gray-400 mt-2">
          <FiMapPin /> {doctor.hospital}
        </p>
        <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
          {doctor.experience}+ yrs experience &middot; {doctor.qualification}
        </p>
        <div className="flex items-center justify-between mt-4">
          <span className="text-sm font-semibold">₹{doctor.consultationFee}</span>
          <Link to={`/doctors/${doctor._id}`} className="btn-primary text-xs py-1.5 px-3">
            Book Now
          </Link>
        </div>
      </div>
    </div>
  );
};

export default DoctorCard;
