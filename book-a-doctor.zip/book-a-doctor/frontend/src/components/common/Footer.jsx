import { Link } from "react-router-dom";
import { FiFacebook, FiTwitter, FiInstagram } from "react-icons/fi";

const Footer = () => {
  return (
    <footer className="bg-white dark:bg-gray-900 border-t border-gray-100 dark:border-gray-800 mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-8">
        <div>
          <h3 className="text-lg font-bold text-primary-600 mb-3">BookADoctor</h3>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Find and book appointments with trusted doctors near you, anytime, anywhere.
          </p>
        </div>
        <div>
          <h4 className="font-semibold mb-3 text-sm">Quick Links</h4>
          <ul className="space-y-2 text-sm text-gray-500 dark:text-gray-400">
            <li><Link to="/" className="hover:text-primary-600">Home</Link></li>
            <li><Link to="/doctors" className="hover:text-primary-600">Find Doctors</Link></li>
            <li><Link to="/about" className="hover:text-primary-600">About Us</Link></li>
            <li><Link to="/contact" className="hover:text-primary-600">Contact</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="font-semibold mb-3 text-sm">For Providers</h4>
          <ul className="space-y-2 text-sm text-gray-500 dark:text-gray-400">
            <li><Link to="/login" className="hover:text-primary-600">Doctor Login</Link></li>
            <li><Link to="/admin/login" className="hover:text-primary-600">Admin Login</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="font-semibold mb-3 text-sm">Follow Us</h4>
          <div className="flex gap-3 text-lg text-gray-500 dark:text-gray-400">
            <a href="#" aria-label="Facebook" className="hover:text-primary-600"><FiFacebook /></a>
            <a href="#" aria-label="Twitter" className="hover:text-primary-600"><FiTwitter /></a>
            <a href="#" aria-label="Instagram" className="hover:text-primary-600"><FiInstagram /></a>
          </div>
        </div>
      </div>
      <div className="border-t border-gray-100 dark:border-gray-800 py-4 text-center text-xs text-gray-400">
        &copy; {new Date().getFullYear()} BookADoctor. All rights reserved.
      </div>
    </footer>
  );
};

export default Footer;
