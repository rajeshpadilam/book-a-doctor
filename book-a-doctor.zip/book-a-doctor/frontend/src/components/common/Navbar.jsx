import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { FiMenu, FiX, FiSun, FiMoon, FiUser } from "react-icons/fi";
import { useAuth } from "../../context/AuthContext";
import { useTheme } from "../../context/ThemeContext";

const Navbar = () => {
  const [open, setOpen] = useState(false);
  const { user, logout } = useAuth();
  const { darkMode, toggleTheme } = useTheme();
  const navigate = useNavigate();

  const dashboardPath =
    user?.role === "doctor" ? "/doctor/dashboard" : user?.role === "admin" ? "/admin/dashboard" : "/patient/dashboard";

  const navLinks = [
    { name: "Home", path: "/" },
    { name: "Doctors", path: "/doctors" },
    { name: "About", path: "/about" },
    { name: "Contact", path: "/contact" },
  ];

  return (
    <header className="sticky top-0 z-50 bg-white/90 dark:bg-gray-900/90 backdrop-blur border-b border-gray-100 dark:border-gray-800">
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        <Link to="/" className="text-xl font-bold text-primary-600">
          Book<span className="text-gray-800 dark:text-white">A</span>Doctor
        </Link>

        {/* Desktop links */}
        <div className="hidden md:flex items-center gap-6">
          {navLinks.map((link) => (
            <Link
              key={link.path}
              to={link.path}
              className="text-sm font-medium text-gray-600 dark:text-gray-300 hover:text-primary-600 transition-colors"
            >
              {link.name}
            </Link>
          ))}
        </div>

        <div className="hidden md:flex items-center gap-3">
          <button
            onClick={toggleTheme}
            aria-label="Toggle dark mode"
            className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800"
          >
            {darkMode ? <FiSun /> : <FiMoon />}
          </button>

          {user ? (
            <div className="flex items-center gap-3">
              <button onClick={() => navigate(dashboardPath)} className="btn-outline text-sm py-1.5">
                <FiUser className="inline mr-1" /> {user.name.split(" ")[0]}
              </button>
              <button onClick={logout} className="btn-primary text-sm py-1.5">
                Logout
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-3">
              <Link to="/login" className="btn-outline text-sm py-1.5">
                Login
              </Link>
              <Link to="/register" className="btn-primary text-sm py-1.5">
                Sign Up
              </Link>
            </div>
          )}
        </div>

        {/* Mobile toggle */}
        <button className="md:hidden text-2xl" onClick={() => setOpen(!open)} aria-label="Toggle menu">
          {open ? <FiX /> : <FiMenu />}
        </button>
      </nav>

      {/* Mobile menu */}
      {open && (
        <div className="md:hidden bg-white dark:bg-gray-900 border-t border-gray-100 dark:border-gray-800 px-4 py-4 space-y-3">
          {navLinks.map((link) => (
            <Link key={link.path} to={link.path} onClick={() => setOpen(false)} className="block text-sm font-medium">
              {link.name}
            </Link>
          ))}
          <div className="flex items-center justify-between pt-3 border-t border-gray-100 dark:border-gray-800">
            <button onClick={toggleTheme} className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800">
              {darkMode ? <FiSun /> : <FiMoon />}
            </button>
            {user ? (
              <div className="flex gap-2">
                <button onClick={() => { navigate(dashboardPath); setOpen(false); }} className="btn-outline text-sm py-1.5">
                  Dashboard
                </button>
                <button onClick={logout} className="btn-primary text-sm py-1.5">
                  Logout
                </button>
              </div>
            ) : (
              <div className="flex gap-2">
                <Link to="/login" onClick={() => setOpen(false)} className="btn-outline text-sm py-1.5">
                  Login
                </Link>
                <Link to="/register" onClick={() => setOpen(false)} className="btn-primary text-sm py-1.5">
                  Sign Up
                </Link>
              </div>
            )}
          </div>
        </div>
      )}
    </header>
  );
};

export default Navbar;
