const Spinner = ({ fullScreen = false, size = "md" }) => {
  const sizeClasses = { sm: "h-5 w-5", md: "h-10 w-10", lg: "h-16 w-16" };

  const spinner = (
    <div
      className={`${sizeClasses[size]} animate-spin rounded-full border-4 border-primary-200 border-t-primary-600`}
    />
  );

  if (fullScreen) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">{spinner}</div>
    );
  }

  return spinner;
};

export default Spinner;
