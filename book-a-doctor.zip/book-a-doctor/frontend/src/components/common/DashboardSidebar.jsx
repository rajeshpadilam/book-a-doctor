import { NavLink } from "react-router-dom";
import { useState } from "react";
import { FiMenu, FiX } from "react-icons/fi";

// Generic responsive sidebar used by Patient / Doctor / Admin dashboards.
// `links` = [{ name, path, icon }]
const DashboardSidebar = ({ links, title }) => {
  const [open, setOpen] = useState(false);

  return (
    <>
      {/* Mobile top bar */}
      <div className="md:hidden flex items-center justify-between p-4 border-b border-gray-100 dark:border-gray-800">
        <h2 className="font-semibold">{title}</h2>
        <button onClick={() => setOpen(!open)}>{open ? <FiX /> : <FiMenu />}</button>
      </div>

      <aside
        className={`${
          open ? "block" : "hidden"
        } md:block w-full md:w-64 shrink-0 bg-white dark:bg-gray-900 border-r border-gray-100 dark:border-gray-800 md:min-h-[calc(100vh-4rem)]`}
      >
        <div className="hidden md:block p-6 font-bold text-lg text-primary-600">{title}</div>
        <nav className="p-3 space-y-1">
          {links.map((link) => (
            <NavLink
              key={link.path}
              to={link.path}
              end
              onClick={() => setOpen(false)}
              className={({ isActive }) =>
                `flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                  isActive
                    ? "bg-primary-600 text-white"
                    : "text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800"
                }`
              }
            >
              {link.icon} {link.name}
            </NavLink>
          ))}
        </nav>
      </aside>
    </>
  );
};

export default DashboardSidebar;
