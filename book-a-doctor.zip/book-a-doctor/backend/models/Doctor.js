const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");

const SPECIALIZATIONS = [
  "General Physician",
  "Cardiologist",
  "Dermatologist",
  "Neurologist",
  "Orthopedic",
  "Pediatrician",
  "Dentist",
  "ENT",
  "Gynecologist",
  "Psychiatrist",
];

// Sub-schema for weekly availability, e.g. { day: "Monday", slots: ["10:00","10:30"] }
const availabilitySchema = new mongoose.Schema(
  {
    day: {
      type: String,
      enum: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
      required: true,
    },
    slots: [{ type: String, required: true }], // e.g. "10:00 AM"
  },
  { _id: false }
);

const doctorSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
      match: [/^\S+@\S+\.\S+$/, "Please provide a valid email"],
    },
    password: { type: String, required: true, minlength: 6, select: false },
    phone: { type: String, trim: true },
    photo: {
      url: { type: String, default: "" },
      publicId: { type: String, default: "" },
    },
    qualification: { type: String, required: true },
    experience: { type: Number, required: true, default: 0 }, // years
    specialization: {
      type: String,
      required: true,
      enum: SPECIALIZATIONS,
    },
    hospital: { type: String, required: true },
    consultationFee: { type: Number, required: true, default: 0 },
    availability: [availabilitySchema],
    languages: [{ type: String }],
    about: { type: String, default: "" },
    rating: { type: Number, default: 0 },
    numReviews: { type: Number, default: 0 },
    earnings: { type: Number, default: 0 }, // accumulated from completed appointments
    isActive: { type: Boolean, default: true }, // admin can deactivate
    role: { type: String, default: "doctor" },
    resetPasswordToken: { type: String },
    resetPasswordExpire: { type: Date },
  },
  { timestamps: true }
);

doctorSchema.pre("save", async function (next) {
  if (!this.isModified("password")) return next();
  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
  next();
});

doctorSchema.methods.matchPassword = async function (enteredPassword) {
  return await bcrypt.compare(enteredPassword, this.password);
};

doctorSchema.statics.SPECIALIZATIONS = SPECIALIZATIONS;

module.exports = mongoose.model("Doctor", doctorSchema);
module.exports.SPECIALIZATIONS = SPECIALIZATIONS;
