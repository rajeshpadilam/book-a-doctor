const mongoose = require("mongoose");

const reviewSchema = new mongoose.Schema(
  {
    patient: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    doctor: { type: mongoose.Schema.Types.ObjectId, ref: "Doctor", required: true },
    appointment: { type: mongoose.Schema.Types.ObjectId, ref: "Appointment", required: true },
    rating: { type: Number, required: true, min: 1, max: 5 },
    comment: { type: String, trim: true, maxlength: 500 },
  },
  { timestamps: true }
);

// One review per appointment
reviewSchema.index({ appointment: 1 }, { unique: true });

// After saving a review, recalculate the doctor's average rating
reviewSchema.statics.recalculateDoctorRating = async function (doctorId) {
  const Doctor = mongoose.model("Doctor");
  const stats = await this.aggregate([
    { $match: { doctor: doctorId } },
    { $group: { _id: "$doctor", avgRating: { $avg: "$rating" }, count: { $sum: 1 } } },
  ]);

  if (stats.length > 0) {
    await Doctor.findByIdAndUpdate(doctorId, {
      rating: Math.round(stats[0].avgRating * 10) / 10,
      numReviews: stats[0].count,
    });
  } else {
    await Doctor.findByIdAndUpdate(doctorId, { rating: 0, numReviews: 0 });
  }
};

reviewSchema.post("save", async function () {
  await this.constructor.recalculateDoctorRating(this.doctor);
});

module.exports = mongoose.model("Review", reviewSchema);
