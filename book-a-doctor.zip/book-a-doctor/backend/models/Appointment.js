const mongoose = require("mongoose");

const appointmentSchema = new mongoose.Schema(
  {
    patient: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    doctor: { type: mongoose.Schema.Types.ObjectId, ref: "Doctor", required: true },
    date: { type: Date, required: true }, // appointment date
    timeSlot: { type: String, required: true }, // e.g. "10:30 AM"
    status: {
      type: String,
      enum: ["pending", "accepted", "rejected", "completed", "cancelled"],
      default: "pending",
    },
    reason: { type: String, default: "" }, // patient's reason for visit
    consultationFee: { type: Number, required: true },
    paymentStatus: { type: String, enum: ["unpaid", "paid"], default: "unpaid" },
    cancelledBy: { type: String, enum: ["patient", "doctor", "admin", null], default: null },
    notes: { type: String, default: "" }, // doctor's notes after completing
  },
  { timestamps: true }
);

// Prevent double-booking of the same doctor/date/slot for active appointments
appointmentSchema.index(
  { doctor: 1, date: 1, timeSlot: 1 },
  {
    unique: true,
    partialFilterExpression: { status: { $in: ["pending", "accepted"] } },
  }
);

module.exports = mongoose.model("Appointment", appointmentSchema);
