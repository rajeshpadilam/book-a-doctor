const jwt = require("jsonwebtoken");

// Generates a signed JWT embedding the user's id and role.
// role is one of: "patient", "doctor", "admin"
const generateToken = (id, role) => {
  return jwt.sign({ id, role }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRE || "7d",
  });
};

module.exports = generateToken;
