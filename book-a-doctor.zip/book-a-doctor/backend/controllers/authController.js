const asyncHandler = require("express-async-handler");
const crypto = require("crypto");
const User = require("../models/User");
const Doctor = require("../models/Doctor");
const Admin = require("../models/Admin");
const generateToken = require("../utils/generateToken");

// @desc    Register a new patient
// @route   POST /api/auth/register
// @access  Public
const registerPatient = asyncHandler(async (req, res) => {
  const { name, email, password, phone, gender, dateOfBirth } = req.body;

  const existingUser = await User.findOne({ email });
  if (existingUser) {
    res.status(400);
    throw new Error("An account with this email already exists");
  }

  const user = await User.create({ name, email, password, phone, gender, dateOfBirth });

  res.status(201).json({
    success: true,
    token: generateToken(user._id, "patient"),
    user: {
      _id: user._id,
      name: user.name,
      email: user.email,
      role: "patient",
      profileImage: user.profileImage,
    },
  });
});

// @desc    Login - works for patient, doctor, and admin based on role in body
// @route   POST /api/auth/login
// @access  Public
const login = asyncHandler(async (req, res) => {
  const { email, password, role = "patient" } = req.body;

  let account;
  let Model;

  if (role === "doctor") Model = Doctor;
  else if (role === "admin") Model = Admin;
  else Model = User;

  account = await Model.findOne({ email }).select("+password");

  if (!account || !(await account.matchPassword(password))) {
    res.status(401);
    throw new Error("Invalid email or password");
  }

  if (role === "doctor" && account.isActive === false) {
    res.status(403);
    throw new Error("Your account has been deactivated. Please contact admin.");
  }

  res.json({
    success: true,
    token: generateToken(account._id, role),
    user: {
      _id: account._id,
      name: account.name,
      email: account.email,
      role,
      profileImage: account.profileImage || account.photo || null,
    },
  });
});

// @desc    Get currently logged in account's basic info
// @route   GET /api/auth/me
// @access  Private
const getMe = asyncHandler(async (req, res) => {
  res.json({ success: true, user: req.user });
});

// @desc    Forgot password - generates reset token (in production this would be emailed)
// @route   POST /api/auth/forgot-password
// @access  Public
const forgotPassword = asyncHandler(async (req, res) => {
  const { email, role = "patient" } = req.body;
  const Model = role === "doctor" ? Doctor : role === "admin" ? Admin : User;

  const account = await Model.findOne({ email });
  if (!account) {
    res.status(404);
    throw new Error("No account found with this email");
  }

  // Generate raw token, store hashed version, expire in 15 minutes
  const resetToken = crypto.randomBytes(32).toString("hex");
  account.resetPasswordToken = crypto.createHash("sha256").update(resetToken).digest("hex");
  account.resetPasswordExpire = Date.now() + 15 * 60 * 1000;
  await account.save({ validateBeforeSave: false });

  // In production: send `resetToken` via email using nodemailer.
  // For this project, we return it directly so the frontend can proceed
  // (replace with real email delivery before going to production).
  res.json({
    success: true,
    message: "Password reset token generated. Check your email.",
    resetToken, // TODO: remove from response once email sending is wired up
  });
});

// @desc    Reset password using token from forgot-password step
// @route   PUT /api/auth/reset-password/:token
// @access  Public
const resetPassword = asyncHandler(async (req, res) => {
  const { role = "patient", password } = req.body;
  const Model = role === "doctor" ? Doctor : role === "admin" ? Admin : User;

  const hashedToken = crypto.createHash("sha256").update(req.params.token).digest("hex");

  const account = await Model.findOne({
    resetPasswordToken: hashedToken,
    resetPasswordExpire: { $gt: Date.now() },
  });

  if (!account) {
    res.status(400);
    throw new Error("Invalid or expired reset token");
  }

  account.password = password;
  account.resetPasswordToken = undefined;
  account.resetPasswordExpire = undefined;
  await account.save();

  res.json({ success: true, message: "Password reset successful. Please login." });
});

module.exports = { registerPatient, login, getMe, forgotPassword, resetPassword };
