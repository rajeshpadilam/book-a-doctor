const asyncHandler = require("express-async-handler");
const Doctor = require("../models/Doctor");
const User = require("../models/User");
const Appointment = require("../models/Appointment");
const cloudinary = require("../config/cloudinary");

// @desc    Admin dashboard statistics
// @route   GET /api/admin/dashboard
// @access  Private (admin)
const getDashboardStats = asyncHandler(async (req, res) => {
  const [totalDoctors, totalPatients, totalAppointments, appointmentsByStatus, revenueAgg] =
    await Promise.all([
      Doctor.countDocuments(),
      User.countDocuments(),
      Appointment.countDocuments(),
      Appointment.aggregate([{ $group: { _id: "$status", count: { $sum: 1 } } }]),
      Appointment.aggregate([
        { $match: { status: "completed" } },
        { $group: { _id: null, total: { $sum: "$consultationFee" } } },
      ]),
    ]);

  const statusMap = appointmentsByStatus.reduce((acc, item) => {
    acc[item._id] = item.count;
    return acc;
  }, {});

  res.json({
    success: true,
    stats: {
      totalDoctors,
      totalPatients,
      totalAppointments,
      totalRevenue: revenueAgg[0]?.total || 0,
      appointmentsByStatus: statusMap,
    },
  });
});

// @desc    Add a new doctor
// @route   POST /api/admin/doctors
// @access  Private (admin)
const addDoctor = asyncHandler(async (req, res) => {
  const existing = await Doctor.findOne({ email: req.body.email });
  if (existing) {
    res.status(400);
    throw new Error("A doctor with this email already exists");
  }

  const doctorData = { ...req.body };
  if (req.file) {
    doctorData.photo = { url: req.file.path, publicId: req.file.filename };
  }
  // languages / availability may arrive as JSON strings from multipart form-data
  if (typeof doctorData.languages === "string") {
    doctorData.languages = JSON.parse(doctorData.languages);
  }
  if (typeof doctorData.availability === "string") {
    doctorData.availability = JSON.parse(doctorData.availability);
  }

  const doctor = await Doctor.create(doctorData);
  res.status(201).json({ success: true, doctor });
});

// @desc    Edit doctor details
// @route   PUT /api/admin/doctors/:id
// @access  Private (admin)
const editDoctor = asyncHandler(async (req, res) => {
  const doctor = await Doctor.findById(req.params.id);
  if (!doctor) {
    res.status(404);
    throw new Error("Doctor not found");
  }

  const updateData = { ...req.body };
  if (typeof updateData.languages === "string") {
    updateData.languages = JSON.parse(updateData.languages);
  }
  if (typeof updateData.availability === "string") {
    updateData.availability = JSON.parse(updateData.availability);
  }

  if (req.file) {
    if (doctor.photo?.publicId) {
      await cloudinary.uploader.destroy(doctor.photo.publicId).catch(() => {});
    }
    updateData.photo = { url: req.file.path, publicId: req.file.filename };
  }

  Object.assign(doctor, updateData);
  const updated = await doctor.save();
  res.json({ success: true, doctor: updated });
});

// @desc    Delete a doctor
// @route   DELETE /api/admin/doctors/:id
// @access  Private (admin)
const deleteDoctor = asyncHandler(async (req, res) => {
  const doctor = await Doctor.findById(req.params.id);
  if (!doctor) {
    res.status(404);
    throw new Error("Doctor not found");
  }

  if (doctor.photo?.publicId) {
    await cloudinary.uploader.destroy(doctor.photo.publicId).catch(() => {});
  }

  await doctor.deleteOne();
  res.json({ success: true, message: "Doctor removed successfully" });
});

// @desc    Get all doctors (admin view - includes inactive) with search/filter
// @route   GET /api/admin/doctors
// @access  Private (admin)
const getAllDoctorsAdmin = asyncHandler(async (req, res) => {
  const { search, specialization, page = 1, limit = 10 } = req.query;
  const filter = {};
  if (search) filter.name = { $regex: search, $options: "i" };
  if (specialization) filter.specialization = specialization;

  const skip = (Number(page) - 1) * Number(limit);
  const [doctors, total] = await Promise.all([
    Doctor.find(filter).sort({ createdAt: -1 }).skip(skip).limit(Number(limit)),
    Doctor.countDocuments(filter),
  ]);

  res.json({
    success: true,
    count: doctors.length,
    total,
    page: Number(page),
    pages: Math.ceil(total / Number(limit)),
    doctors,
  });
});

// @desc    Toggle doctor active/inactive status
// @route   PUT /api/admin/doctors/:id/status
// @access  Private (admin)
const toggleDoctorStatus = asyncHandler(async (req, res) => {
  const doctor = await Doctor.findById(req.params.id);
  if (!doctor) {
    res.status(404);
    throw new Error("Doctor not found");
  }
  doctor.isActive = !doctor.isActive;
  await doctor.save();
  res.json({ success: true, doctor });
});

// @desc    Get all patients (with search + pagination)
// @route   GET /api/admin/patients
// @access  Private (admin)
const getAllPatients = asyncHandler(async (req, res) => {
  const { search, page = 1, limit = 10 } = req.query;
  const filter = {};
  if (search) filter.name = { $regex: search, $options: "i" };

  const skip = (Number(page) - 1) * Number(limit);
  const [patients, total] = await Promise.all([
    User.find(filter).sort({ createdAt: -1 }).skip(skip).limit(Number(limit)),
    User.countDocuments(filter),
  ]);

  res.json({
    success: true,
    count: patients.length,
    total,
    page: Number(page),
    pages: Math.ceil(total / Number(limit)),
    patients,
  });
});

// @desc    Delete a patient account
// @route   DELETE /api/admin/patients/:id
// @access  Private (admin)
const deletePatient = asyncHandler(async (req, res) => {
  const patient = await User.findById(req.params.id);
  if (!patient) {
    res.status(404);
    throw new Error("Patient not found");
  }
  if (patient.profileImage?.publicId) {
    await cloudinary.uploader.destroy(patient.profileImage.publicId).catch(() => {});
  }
  await patient.deleteOne();
  res.json({ success: true, message: "Patient removed successfully" });
});

// @desc    Get all appointments (admin view) with optional filters
// @route   GET /api/admin/appointments
// @access  Private (admin)
const getAllAppointments = asyncHandler(async (req, res) => {
  const { status, page = 1, limit = 10 } = req.query;
  const filter = {};
  if (status) filter.status = status;

  const skip = (Number(page) - 1) * Number(limit);
  const [appointments, total] = await Promise.all([
    Appointment.find(filter)
      .populate("patient", "name email phone")
      .populate("doctor", "name specialization hospital")
      .sort({ date: -1 })
      .skip(skip)
      .limit(Number(limit)),
    Appointment.countDocuments(filter),
  ]);

  res.json({
    success: true,
    count: appointments.length,
    total,
    page: Number(page),
    pages: Math.ceil(total / Number(limit)),
    appointments,
  });
});

// @desc    Get revenue report (grouped by month)
// @route   GET /api/admin/revenue
// @access  Private (admin)
const getRevenueReport = asyncHandler(async (req, res) => {
  const revenue = await Appointment.aggregate([
    { $match: { status: "completed" } },
    {
      $group: {
        _id: { year: { $year: "$updatedAt" }, month: { $month: "$updatedAt" } },
        total: { $sum: "$consultationFee" },
        count: { $sum: 1 },
      },
    },
    { $sort: { "_id.year": 1, "_id.month": 1 } },
  ]);

  res.json({ success: true, revenue });
});

// @desc    Get list of specializations in use (for managing specializations)
// @route   GET /api/admin/specializations
// @access  Private (admin)
const getSpecializationStats = asyncHandler(async (req, res) => {
  const stats = await Doctor.aggregate([
    { $group: { _id: "$specialization", doctorCount: { $sum: 1 } } },
    { $sort: { doctorCount: -1 } },
  ]);
  res.json({ success: true, specializations: Doctor.SPECIALIZATIONS, stats });
});

module.exports = {
  getDashboardStats,
  addDoctor,
  editDoctor,
  deleteDoctor,
  getAllDoctorsAdmin,
  toggleDoctorStatus,
  getAllPatients,
  deletePatient,
  getAllAppointments,
  getRevenueReport,
  getSpecializationStats,
};
