const asyncHandler = require("express-async-handler");
const User = require("../models/User");
const Appointment = require("../models/Appointment");
const Doctor = require("../models/Doctor");
const Review = require("../models/Review");
const cloudinary = require("../config/cloudinary");

// @desc    Update patient profile
// @route   PUT /api/patients/profile
// @access  Private (patient)
const updateProfile = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id);
  if (!user) {
    res.status(404);
    throw new Error("User not found");
  }

  const fields = ["name", "phone", "gender", "dateOfBirth", "address"];
  fields.forEach((field) => {
    if (req.body[field] !== undefined) user[field] = req.body[field];
  });

  const updated = await user.save();
  res.json({ success: true, user: updated });
});

// @desc    Upload / update profile picture
// @route   PUT /api/patients/profile/image
// @access  Private (patient)
const uploadProfileImage = asyncHandler(async (req, res) => {
  if (!req.file) {
    res.status(400);
    throw new Error("Please upload an image file");
  }

  const user = await User.findById(req.user._id);

  // Remove old image from Cloudinary if present
  if (user.profileImage?.publicId) {
    await cloudinary.uploader.destroy(user.profileImage.publicId).catch(() => {});
  }

  user.profileImage = { url: req.file.path, publicId: req.file.filename };
  await user.save();

  res.json({ success: true, profileImage: user.profileImage });
});

// @desc    Book an appointment
// @route   POST /api/patients/appointments
// @access  Private (patient)
const bookAppointment = asyncHandler(async (req, res) => {
  const { doctorId, date, timeSlot, reason } = req.body;

  const doctor = await Doctor.findById(doctorId);
  if (!doctor || !doctor.isActive) {
    res.status(404);
    throw new Error("Doctor not found or unavailable");
  }

  // Validate the requested slot actually belongs to the doctor's availability
  const dayName = new Date(date).toLocaleDateString("en-US", { weekday: "long" });
  const dayAvailability = doctor.availability.find((a) => a.day === dayName);
  if (!dayAvailability || !dayAvailability.slots.includes(timeSlot)) {
    res.status(400);
    throw new Error("Selected time slot is not available for this doctor");
  }

  // Check slot isn't already booked (active appointment)
  const clash = await Appointment.findOne({
    doctor: doctorId,
    date: new Date(date),
    timeSlot,
    status: { $in: ["pending", "accepted"] },
  });
  if (clash) {
    res.status(409);
    throw new Error("This time slot has just been booked. Please choose another.");
  }

  const appointment = await Appointment.create({
    patient: req.user._id,
    doctor: doctorId,
    date,
    timeSlot,
    reason,
    consultationFee: doctor.consultationFee,
  });

  res.status(201).json({ success: true, appointment });
});

// @desc    Get logged-in patient's appointment history
// @route   GET /api/patients/appointments
// @access  Private (patient)
const getMyAppointments = asyncHandler(async (req, res) => {
  const { status } = req.query;
  const filter = { patient: req.user._id };
  if (status) filter.status = status;

  const appointments = await Appointment.find(filter)
    .populate("doctor", "name photo specialization hospital consultationFee")
    .sort({ date: -1, createdAt: -1 });

  res.json({ success: true, count: appointments.length, appointments });
});

// @desc    Cancel an appointment
// @route   PUT /api/patients/appointments/:id/cancel
// @access  Private (patient)
const cancelAppointment = asyncHandler(async (req, res) => {
  const appointment = await Appointment.findById(req.params.id);

  if (!appointment) {
    res.status(404);
    throw new Error("Appointment not found");
  }
  if (appointment.patient.toString() !== req.user._id.toString()) {
    res.status(403);
    throw new Error("Not authorized to cancel this appointment");
  }
  if (["completed", "cancelled", "rejected"].includes(appointment.status)) {
    res.status(400);
    throw new Error(`Cannot cancel an appointment that is already ${appointment.status}`);
  }

  appointment.status = "cancelled";
  appointment.cancelledBy = "patient";
  await appointment.save();

  res.json({ success: true, message: "Appointment cancelled", appointment });
});

// @desc    Leave a review for a completed appointment
// @route   POST /api/patients/reviews
// @access  Private (patient)
const addReview = asyncHandler(async (req, res) => {
  const { appointmentId, rating, comment } = req.body;

  const appointment = await Appointment.findById(appointmentId);
  if (!appointment || appointment.patient.toString() !== req.user._id.toString()) {
    res.status(404);
    throw new Error("Appointment not found");
  }
  if (appointment.status !== "completed") {
    res.status(400);
    throw new Error("You can only review completed appointments");
  }

  const review = await Review.create({
    patient: req.user._id,
    doctor: appointment.doctor,
    appointment: appointmentId,
    rating,
    comment,
  });

  res.status(201).json({ success: true, review });
});

module.exports = {
  updateProfile,
  uploadProfileImage,
  bookAppointment,
  getMyAppointments,
  cancelAppointment,
  addReview,
};
