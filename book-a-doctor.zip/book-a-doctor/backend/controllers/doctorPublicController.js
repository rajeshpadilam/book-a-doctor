const asyncHandler = require("express-async-handler");
const Doctor = require("../models/Doctor");
const Review = require("../models/Review");

// @desc    Get all doctors with search, specialization filter, and pagination
// @route   GET /api/doctors?search=&specialization=&page=&limit=
// @access  Public
const getDoctors = asyncHandler(async (req, res) => {
  const { search, specialization, page = 1, limit = 9, sort = "-rating" } = req.query;

  const filter = { isActive: true };
  if (search) filter.name = { $regex: search, $options: "i" };
  if (specialization) filter.specialization = specialization;

  const skip = (Number(page) - 1) * Number(limit);

  const [doctors, total] = await Promise.all([
    Doctor.find(filter).sort(sort).skip(skip).limit(Number(limit)),
    Doctor.countDocuments(filter),
  ]);

  res.json({
    success: true,
    count: doctors.length,
    total,
    page: Number(page),
    pages: Math.ceil(total / Number(limit)),
    doctors,
  });
});

// @desc    Get single doctor profile with reviews
// @route   GET /api/doctors/:id
// @access  Public
const getDoctorById = asyncHandler(async (req, res) => {
  const doctor = await Doctor.findById(req.params.id);
  if (!doctor) {
    res.status(404);
    throw new Error("Doctor not found");
  }

  const reviews = await Review.find({ doctor: doctor._id })
    .populate("patient", "name profileImage")
    .sort({ createdAt: -1 });

  res.json({ success: true, doctor, reviews });
});

// @desc    Get list of all specializations (static enum)
// @route   GET /api/doctors/specializations
// @access  Public
const getSpecializations = asyncHandler(async (req, res) => {
  res.json({ success: true, specializations: Doctor.SPECIALIZATIONS });
});

module.exports = { getDoctors, getDoctorById, getSpecializations };
