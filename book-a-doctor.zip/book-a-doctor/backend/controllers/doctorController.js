const asyncHandler = require("express-async-handler");
const Doctor = require("../models/Doctor");
const Appointment = require("../models/Appointment");
const cloudinary = require("../config/cloudinary");

// @desc    Get logged-in doctor's dashboard stats + today's appointments
// @route   GET /api/doctor/dashboard
// @access  Private (doctor)
const getDashboard = asyncHandler(async (req, res) => {
  const doctorId = req.user._id;

  const startOfDay = new Date();
  startOfDay.setHours(0, 0, 0, 0);
  const endOfDay = new Date();
  endOfDay.setHours(23, 59, 59, 999);

  const [todayAppointments, totalAppointments, completed, pending, doctor] = await Promise.all([
    Appointment.find({ doctor: doctorId, date: { $gte: startOfDay, $lte: endOfDay } })
      .populate("patient", "name phone profileImage")
      .sort({ timeSlot: 1 }),
    Appointment.countDocuments({ doctor: doctorId }),
    Appointment.countDocuments({ doctor: doctorId, status: "completed" }),
    Appointment.countDocuments({ doctor: doctorId, status: "pending" }),
    Doctor.findById(doctorId),
  ]);

  res.json({
    success: true,
    stats: {
      totalAppointments,
      completed,
      pending,
      earnings: doctor.earnings,
      rating: doctor.rating,
      numReviews: doctor.numReviews,
    },
    todayAppointments,
  });
});

// @desc    Get all appointments for logged-in doctor (with optional status filter)
// @route   GET /api/doctor/appointments
// @access  Private (doctor)
const getDoctorAppointments = asyncHandler(async (req, res) => {
  const { status } = req.query;
  const filter = { doctor: req.user._id };
  if (status) filter.status = status;

  const appointments = await Appointment.find(filter)
    .populate("patient", "name phone email profileImage gender dateOfBirth")
    .sort({ date: -1 });

  res.json({ success: true, count: appointments.length, appointments });
});

// @desc    Accept a pending appointment
// @route   PUT /api/doctor/appointments/:id/accept
// @access  Private (doctor)
const acceptAppointment = asyncHandler(async (req, res) => {
  const appointment = await getOwnedAppointment(req);
  if (appointment.status !== "pending") {
    res.status(400);
    throw new Error("Only pending appointments can be accepted");
  }
  appointment.status = "accepted";
  await appointment.save();
  res.json({ success: true, appointment });
});

// @desc    Reject a pending appointment
// @route   PUT /api/doctor/appointments/:id/reject
// @access  Private (doctor)
const rejectAppointment = asyncHandler(async (req, res) => {
  const appointment = await getOwnedAppointment(req);
  if (appointment.status !== "pending") {
    res.status(400);
    throw new Error("Only pending appointments can be rejected");
  }
  appointment.status = "rejected";
  appointment.cancelledBy = "doctor";
  await appointment.save();
  res.json({ success: true, appointment });
});

// @desc    Mark an accepted appointment as completed (also credits doctor earnings)
// @route   PUT /api/doctor/appointments/:id/complete
// @access  Private (doctor)
const completeAppointment = asyncHandler(async (req, res) => {
  const appointment = await getOwnedAppointment(req);
  if (appointment.status !== "accepted") {
    res.status(400);
    throw new Error("Only accepted appointments can be marked complete");
  }
  appointment.status = "completed";
  appointment.paymentStatus = "paid";
  if (req.body.notes) appointment.notes = req.body.notes;
  await appointment.save();

  await Doctor.findByIdAndUpdate(req.user._id, {
    $inc: { earnings: appointment.consultationFee },
  });

  res.json({ success: true, appointment });
});

// Helper: fetch an appointment and verify it belongs to the logged-in doctor
const getOwnedAppointment = async (req) => {
  const appointment = await Appointment.findById(req.params.id);
  if (!appointment) {
    const err = new Error("Appointment not found");
    err.statusCode = 404;
    throw err;
  }
  if (appointment.doctor.toString() !== req.user._id.toString()) {
    const err = new Error("Not authorized to modify this appointment");
    err.statusCode = 403;
    throw err;
  }
  return appointment;
};

// @desc    Update own availability (days + slots)
// @route   PUT /api/doctor/availability
// @access  Private (doctor)
const updateAvailability = asyncHandler(async (req, res) => {
  const { availability } = req.body; // [{ day, slots: [] }]
  const doctor = await Doctor.findById(req.user._id);
  doctor.availability = availability;
  await doctor.save();
  res.json({ success: true, availability: doctor.availability });
});

// @desc    Update own profile
// @route   PUT /api/doctor/profile
// @access  Private (doctor)
const updateDoctorProfile = asyncHandler(async (req, res) => {
  const doctor = await Doctor.findById(req.user._id);
  const fields = [
    "name",
    "phone",
    "qualification",
    "experience",
    "specialization",
    "hospital",
    "consultationFee",
    "languages",
    "about",
  ];
  fields.forEach((field) => {
    if (req.body[field] !== undefined) doctor[field] = req.body[field];
  });
  const updated = await doctor.save();
  res.json({ success: true, doctor: updated });
});

// @desc    Upload own profile photo
// @route   PUT /api/doctor/profile/image
// @access  Private (doctor)
const uploadDoctorImage = asyncHandler(async (req, res) => {
  if (!req.file) {
    res.status(400);
    throw new Error("Please upload an image file");
  }
  const doctor = await Doctor.findById(req.user._id);

  if (doctor.photo?.publicId) {
    await cloudinary.uploader.destroy(doctor.photo.publicId).catch(() => {});
  }

  doctor.photo = { url: req.file.path, publicId: req.file.filename };
  await doctor.save();

  res.json({ success: true, photo: doctor.photo });
});

// @desc    View earnings breakdown
// @route   GET /api/doctor/earnings
// @access  Private (doctor)
const getEarnings = asyncHandler(async (req, res) => {
  const doctor = await Doctor.findById(req.user._id);
  const completedAppointments = await Appointment.find({
    doctor: req.user._id,
    status: "completed",
  })
    .populate("patient", "name")
    .sort({ updatedAt: -1 });

  res.json({
    success: true,
    totalEarnings: doctor.earnings,
    completedCount: completedAppointments.length,
    transactions: completedAppointments,
  });
});

module.exports = {
  getDashboard,
  getDoctorAppointments,
  acceptAppointment,
  rejectAppointment,
  completeAppointment,
  updateAvailability,
  updateDoctorProfile,
  uploadDoctorImage,
  getEarnings,
};
