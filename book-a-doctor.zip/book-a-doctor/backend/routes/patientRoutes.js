const express = require("express");
const {
  updateProfile,
  uploadProfileImage,
  bookAppointment,
  getMyAppointments,
  cancelAppointment,
  addReview,
} = require("../controllers/patientController");
const { protect, authorize } = require("../middleware/authMiddleware");
const upload = require("../middleware/uploadMiddleware");

const router = express.Router();

router.use(protect, authorize("patient"));

router.put("/profile", updateProfile);
router.put("/profile/image", upload.single("image"), uploadProfileImage);

router.post("/appointments", bookAppointment);
router.get("/appointments", getMyAppointments);
router.put("/appointments/:id/cancel", cancelAppointment);

router.post("/reviews", addReview);

module.exports = router;
