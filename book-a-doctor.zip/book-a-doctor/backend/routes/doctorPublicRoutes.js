const express = require("express");
const {
  getDoctors,
  getDoctorById,
  getSpecializations,
} = require("../controllers/doctorPublicController");

const router = express.Router();

// NOTE: static route registered before dynamic :id route to avoid conflicts
router.get("/specializations", getSpecializations);
router.get("/", getDoctors);
router.get("/:id", getDoctorById);

module.exports = router;
