const express = require("express");
const {
  getDashboard,
  getDoctorAppointments,
  acceptAppointment,
  rejectAppointment,
  completeAppointment,
  updateAvailability,
  updateDoctorProfile,
  uploadDoctorImage,
  getEarnings,
} = require("../controllers/doctorController");
const { protect, authorize } = require("../middleware/authMiddleware");
const upload = require("../middleware/uploadMiddleware");

const router = express.Router();

router.use(protect, authorize("doctor"));

router.get("/dashboard", getDashboard);

router.get("/appointments", getDoctorAppointments);
router.put("/appointments/:id/accept", acceptAppointment);
router.put("/appointments/:id/reject", rejectAppointment);
router.put("/appointments/:id/complete", completeAppointment);

router.put("/availability", updateAvailability);
router.put("/profile", updateDoctorProfile);
router.put("/profile/image", upload.single("image"), uploadDoctorImage);

router.get("/earnings", getEarnings);

module.exports = router;
