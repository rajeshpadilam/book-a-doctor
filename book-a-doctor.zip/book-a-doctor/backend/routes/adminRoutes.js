const express = require("express");
const {
  getDashboardStats,
  addDoctor,
  editDoctor,
  deleteDoctor,
  getAllDoctorsAdmin,
  toggleDoctorStatus,
  getAllPatients,
  deletePatient,
  getAllAppointments,
  getRevenueReport,
  getSpecializationStats,
} = require("../controllers/adminController");
const { protect, authorize } = require("../middleware/authMiddleware");
const upload = require("../middleware/uploadMiddleware");

const router = express.Router();

router.use(protect, authorize("admin"));

router.get("/dashboard", getDashboardStats);

router.route("/doctors")
  .get(getAllDoctorsAdmin)
  .post(upload.single("photo"), addDoctor);

router.route("/doctors/:id")
  .put(upload.single("photo"), editDoctor)
  .delete(deleteDoctor);

router.put("/doctors/:id/status", toggleDoctorStatus);

router.get("/patients", getAllPatients);
router.delete("/patients/:id", deletePatient);

router.get("/appointments", getAllAppointments);
router.get("/revenue", getRevenueReport);
router.get("/specializations", getSpecializationStats);

module.exports = router;
