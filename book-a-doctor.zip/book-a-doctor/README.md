# Book A Doctor — Full Stack MERN Application

A production-ready doctor appointment booking platform with three modules: **Patient**, **Doctor**, and **Admin**. Built with MongoDB, Express, React (Vite), Node.js, JWT auth, Tailwind CSS, and Cloudinary.

## Tech Stack

- **Frontend:** React 18 (Vite), React Router DOM, Context API, Tailwind CSS, Axios, react-hot-toast, react-icons
- **Backend:** Node.js, Express.js, MongoDB + Mongoose, JWT, Bcrypt, Multer + Cloudinary, express-validator

## Project Structure

```
book-a-doctor/
├── backend/
│   ├── config/          # db.js, cloudinary.js
│   ├── controllers/     # authController, patientController, doctorController,
│   │                       doctorPublicController, adminController
│   ├── models/          # User, Doctor, Appointment, Admin, Review
│   ├── routes/          # authRoutes, doctorPublicRoutes, patientRoutes,
│   │                       doctorRoutes, adminRoutes
│   ├── middleware/      # authMiddleware, errorMiddleware, uploadMiddleware, validateMiddleware
│   ├── utils/           # generateToken
│   ├── seed/             # seedAdmin.js — creates the first admin account
│   ├── server.js
│   ├── .env.example
│   └── package.json
└── frontend/
    ├── src/
    │   ├── api/axios.js
    │   ├── context/     # AuthContext, ThemeContext
    │   ├── components/  # common/, patient/
    │   ├── pages/        # public pages + patient/, doctor/, admin/ subfolders
    │   ├── App.jsx
    │   └── main.jsx
    ├── tailwind.config.js
    ├── vite.config.js
    ├── .env.example
    └── package.json
```

## Getting Started

### 1. Backend Setup

```bash
cd backend
npm install
cp .env.example .env
# Edit .env with your MongoDB URI, JWT secret, Cloudinary keys, and admin credentials
npm run dev          # starts on http://localhost:5000
```

Seed the first admin account (run once):
```bash
node seed/seedAdmin.js
```

### 2. Frontend Setup

```bash
cd frontend
npm install
cp .env.example .env
npm run dev          # starts on http://localhost:5173
```

The Vite dev server proxies `/api` requests to `http://localhost:5000` automatically (see `vite.config.js`), so you don't need CORS configuration in development beyond what's already in `server.js`.

## Environment Variables

### Backend (`backend/.env`)
| Variable | Description |
|---|---|
| `MONGO_URI` | MongoDB connection string |
| `JWT_SECRET` | Secret used to sign JWTs |
| `JWT_EXPIRE` | Token expiry (e.g. `7d`) |
| `ADMIN_EMAIL` / `ADMIN_PASSWORD` | Used once by `seed/seedAdmin.js` |
| `CLOUDINARY_CLOUD_NAME` / `CLOUDINARY_API_KEY` / `CLOUDINARY_API_SECRET` | Image uploads |
| `CLIENT_URL` | Frontend origin, for CORS |

### Frontend (`frontend/.env`)
| Variable | Description |
|---|---|
| `VITE_API_URL` | Backend API base URL (production only; dev uses the Vite proxy) |

## Core API Endpoints

**Auth** — `/api/auth`
- `POST /register` — patient signup
- `POST /login` — patient/doctor/admin login (`role` in body)
- `GET /me` — current session (protected)
- `POST /forgot-password`, `PUT /reset-password/:token`

**Public Doctors** — `/api/doctors`
- `GET /` — list with `search`, `specialization`, `page`, `limit`
- `GET /:id` — profile + reviews
- `GET /specializations`

**Patient** — `/api/patients` (protected, role: patient)
- `PUT /profile`, `PUT /profile/image`
- `POST /appointments`, `GET /appointments`, `PUT /appointments/:id/cancel`
- `POST /reviews`

**Doctor** — `/api/doctor` (protected, role: doctor)
- `GET /dashboard`, `GET /appointments`
- `PUT /appointments/:id/accept|reject|complete`
- `PUT /availability`, `PUT /profile`, `PUT /profile/image`, `GET /earnings`

**Admin** — `/api/admin` (protected, role: admin)
- `GET /dashboard`
- `GET|POST /doctors`, `PUT|DELETE /doctors/:id`, `PUT /doctors/:id/status`
- `GET /patients`, `DELETE /patients/:id`
- `GET /appointments`, `GET /revenue`, `GET /specializations`

## Deployment

**Backend** — Deploy to Render / Railway / an EC2/VPS instance:
1. Set all backend env vars in the host's dashboard.
2. Build command: `npm install`. Start command: `npm start`.
3. Ensure MongoDB Atlas (or your Mongo host) allows connections from the deployment IP.

**Frontend** — Deploy to Vercel / Netlify:
1. Build command: `npm run build`. Output directory: `dist`.
2. Set `VITE_API_URL` to your deployed backend URL, e.g. `https://your-api.onrender.com/api`.
3. Update `CLIENT_URL` in the backend `.env` to your deployed frontend URL for CORS.

**Database** — Use MongoDB Atlas for a managed production database; whitelist your backend host's IP (or `0.0.0.0/0` for platforms with dynamic IPs, paired with strong DB credentials).

## Notes & Next Steps

- `forgotPassword` currently returns the reset token directly in the API response for demo purposes — wire up `nodemailer` (already a dependency) to email it instead before going to production.
- Doctors are onboarded exclusively by the Admin (`POST /api/admin/doctors`) — there's no public doctor self-registration, matching the spec.
- Slot double-booking is prevented at the database level via a partial unique index on `(doctor, date, timeSlot)` for active appointments, plus an application-level check in the controller.
- Dark mode is implemented via Tailwind's `class` strategy and persisted in `localStorage`.
